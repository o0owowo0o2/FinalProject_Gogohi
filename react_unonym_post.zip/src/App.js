import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import Main from './components/Main';
import FooterSje from './components/FooterSje';
import 'bootstrap/dist/css/bootstrap.css';
import HeaderSje from './components/Headersje';
import { Switch } from 'react-router-dom/cjs/react-router-dom.min';
import Contact_us_jje from './components/Contact_us_jje';
import Landingpage_jje from './components/Landingpage_jje';
import Student_create_post_jje from './components/Student_create_post_jje';
import Student_Edit_jje from './components/Student_Edit_jje';
import Student_post_jje from './components/Student_post_jje';
import Student_post_detail_jje from './components/Student_post_detail_jje';

function App() {
  return (
    <div>
      <Router>
      <div id='app'>
        <HeaderSje />  {/* 조건부 헤더 렌더링 */}
        <Switch>
        <Route exact path='/' component={Landingpage_jje}></Route>
        <Route path='/main' component={Main}></Route>
        <Route path='/student_edit/:boardNumber' component={Student_Edit_jje}></Route>
        <Route path='/student_list' component={Student_post_jje}></Route>
        <Route path='/student_create_post_' component={Student_create_post_jje}></Route>
        <Route path='/student/:boardNumber'component={Student_post_detail_jje}></Route>
        <Route path='/contact_us' component={Contact_us_jje}></Route>
        </Switch>
      <FooterSje />
        </div>
      </Router>
    </div>
  );
}

export default App;
