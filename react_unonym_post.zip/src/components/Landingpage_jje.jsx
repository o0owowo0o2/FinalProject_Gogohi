import React from 'react';
import { Link } from 'react-router-dom';
import '../css/landing.css';

function Landingpage_jje() {
    return (
  <div>
            <div className='landing-content'>
                <h1 className='landing-title'>환영합니다!</h1>
                <p className='landing-subtitle'><Link to="/main">미래를 여는 교육, 하이중학교</Link></p>
            </div>
            <video className='background-video' autoPlay muted loop>       
                <source src="videos/school_video.mp4" type="video/mp4" />
            </video>
        </div>
    );
}

export default Landingpage_jje;
