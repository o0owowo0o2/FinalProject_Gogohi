package com.springboot.react.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.springboot.react.entity.Notice_mjh;
import com.springboot.react.service.NoticeService_mjh;

@RestController
@RequestMapping("/api/notice_mjh")
public class NoticeController_mjh {
		
	private NoticeService_mjh noticeService_mjh;

	@Autowired
	public NoticeController_mjh(NoticeService_mjh noticeService_mjh) {
		this.noticeService_mjh = noticeService_mjh;
	}
// 이미지 파일 저장 경로 설정
	private final Path rootLocation = Paths.get("C:/react_images"); 
		
	
	// 이미지 x 게시글 등록 메서드
//		 @PostMapping
//		 public Notice_mjh createNotice_mjh(@RequestBody Notice_mjh notice_mjh) {
//		     // @RequestBody 어노테이션은 HTTP 요청의 본문을 Java 객체로 매핑합니다.
//		     // 이 메소드는 클라이언트로부터 받은 객체를 Service를 통해 저장하고,
//		     // 저장된  객체를 반환합니다.
//		    return noticeService_mjh.saveNotice_mjh(notice_mjh);
//		}
	
	// 이미지 업로드 및 게시글 등록을 위한 API
    @PostMapping("/upload")
    public ResponseEntity<?> uploadImage(@RequestParam("image") MultipartFile file,
                                         @RequestParam("notice") String noticeStr) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper(); // JSON 문자열을 Post 객체로 변환
        Notice_mjh notice_mjh = objectMapper.readValue(noticeStr, Notice_mjh.class); //  데이터 매핑

        String fileName = file.getOriginalFilename(); // 업로드된 파일 이름 추출
        // 파일을 지정된 경로에 저장
        Files.copy(file.getInputStream(), this.rootLocation.resolve(fileName), StandardCopyOption.REPLACE_EXISTING);        

        // 파일 다운로드 URI 생성
        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/downloadFile/")
                .path(fileName)
                .toUriString();
        notice_mjh.setImagePath(fileDownloadUri); // 파일 경로를  객체에 설정

        Notice_mjh savedNotice_mjh = noticeService_mjh.saveNotice_mjh(notice_mjh); // Post 객체 저장 및 반환

        return ResponseEntity.ok("게시글이 등록되었습니다. ID: " + savedNotice_mjh.getNoticeNumber()); // 응답 반환
    }
	
   
	// 페이징 처리를 추가한 게시글 목록 조회 메서드
    @GetMapping("/list")
    public ResponseEntity<Page<Notice_mjh>> getAllnotices_mjh(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "5") int size, @RequestParam(required = false)String search){
		Pageable pageable = PageRequest.of(page, size);
		Page<Notice_mjh> notices_mjh;
		if (search != null && !search.trim().isEmpty()) { notices_mjh = noticeService_mjh.findAllBySearch(search, pageable); 
		}else {
			notices_mjh = noticeService_mjh.findAll(pageable);
		}
		return ResponseEntity.ok(notices_mjh);
	}
    
 // 특정 아이디로 게시글 조회
 		@GetMapping("/{id}")
 		public ResponseEntity<Notice_mjh> getNotice_mjhById(@PathVariable Long id){
 			Optional<Notice_mjh> notice_mjh = noticeService_mjh.findNotice_mjhById(id);
 			return ResponseEntity.ok(notice_mjh.get()); 
 		}
 		
 	// 글 삭제 메서드
 		@DeleteMapping("/{id}")
 		public ResponseEntity<?> deleteNotice_mjh(@PathVariable Long id) {
 			noticeService_mjh.deleteNotice_mjh(id);
 			return ResponseEntity.ok().build();
 		}
 		 
 		// 게시글 수정 API
 	    @PutMapping("/update/{id}")
 	    public ResponseEntity<?> updateNotice_mjh(@PathVariable Long id, @RequestParam("image") MultipartFile file, @RequestParam("notice_mjh") String noticeStr) throws IOException {
 	        ObjectMapper objectMapper = new ObjectMapper(); // JSON 매핑
 	        Notice_mjh notice_mjhToUpdate = objectMapper.readValue(noticeStr, Notice_mjh.class); // 수정할 Post 객체

 	        // 기존 게시글 조회
 	       Notice_mjh existingNotice_mjh = noticeService_mjh.findNotice_mjhById(id).orElseThrow(() -> new RuntimeException("Notice not found with id " + id));

 	        String fileName = file.getOriginalFilename(); // 파일 이름 추출
 	        Files.copy(file.getInputStream(), this.rootLocation.resolve(fileName), StandardCopyOption.REPLACE_EXISTING); // 파일 저장

 	        // 파일 다운로드 URI 설정
 	        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
 	                .path("/downloadFile/")
 	                .path(fileName)
 	                .toUriString();

 	        // Notice_mjh 정보 업데이트
 	       existingNotice_mjh.setNoticeTitle(notice_mjhToUpdate.getNoticeTitle());
 	       existingNotice_mjh.setNoticeContents(notice_mjhToUpdate.getNoticeContents());
 	       existingNotice_mjh.setNoticeDate(notice_mjhToUpdate.getNoticeDate());
 	       existingNotice_mjh.setImagePath(fileDownloadUri);

 	        // 수정된 게시글 저장 및 반환
 	        Notice_mjh updatedNotice_mjh = noticeService_mjh.saveNotice_mjh(existingNotice_mjh);
 	        return ResponseEntity.ok("게시글이 수정되었습니다. ID: " + updatedNotice_mjh.getNoticeNumber()); // 응답 반환
 	    }
}
