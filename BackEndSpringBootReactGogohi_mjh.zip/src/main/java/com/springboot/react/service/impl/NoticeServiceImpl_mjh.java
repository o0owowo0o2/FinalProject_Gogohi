package com.springboot.react.service.impl;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.springboot.react.entity.Notice_mjh;
import com.springboot.react.repository.NoticeRepository_mjh;
import com.springboot.react.service.NoticeService_mjh;

@Service
public class NoticeServiceImpl_mjh implements NoticeService_mjh {
	
	private final NoticeRepository_mjh noticeRepository_mjh;
		
	@Autowired
	public NoticeServiceImpl_mjh(NoticeRepository_mjh noticeRepository_mjh) {
		this.noticeRepository_mjh = noticeRepository_mjh;
	}
	
	@Override
	@Transactional
	public Notice_mjh saveNotice_mjh(Notice_mjh notice_mjh) {
		return noticeRepository_mjh.save(notice_mjh);
	}

	@Override
	public Page<Notice_mjh> findAll(Pageable pageable) {
		return noticeRepository_mjh.findAll(pageable);
	}

	@Override
	public Optional<Notice_mjh> findById(Long id) {
		return null;
	}

	@Override
	public Optional<Notice_mjh> findNotice_mjhById(Long id) {
		return noticeRepository_mjh.findById(id);
	}

	@Override
	public Page<Notice_mjh> findAllBySearch(String search, Pageable pageable) {
		// 검색어가 제공된 경우 해당 검색어를 포함하는 게시글을 조회합니다.
		if (search != null && !search.trim().isEmpty()) {
			return noticeRepository_mjh.findByNoticeTitleContainingOrNoticeContentsContainingOrNoticeWriterContaining(search, search, search, pageable);
		}else {
			return noticeRepository_mjh.findAll(pageable);
		}
	}

	@Override
	public Notice_mjh updateNotice_mjh(Long id, Notice_mjh notice_mjhDetails) {
		Notice_mjh notice_mjh = noticeRepository_mjh.findById(id).orElseThrow(()-> new RuntimeException("Notice_mjh not found with id" + id));
		notice_mjh.setNoticeTitle(notice_mjhDetails.getNoticeTitle());
		notice_mjh.setNoticeContents(notice_mjhDetails.getNoticeContents());
		Notice_mjh updateNotice_mjh = noticeRepository_mjh.save(notice_mjh);
		return updateNotice_mjh;
	}

	@Override
	@Transactional
	public void deleteNotice_mjh(Long id) {
	    noticeRepository_mjh.deleteById(id);
	}

}

