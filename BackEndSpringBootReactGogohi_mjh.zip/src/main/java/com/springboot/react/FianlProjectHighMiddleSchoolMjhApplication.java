package com.springboot.react;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FianlProjectHighMiddleSchoolMjhApplication {

	public static void main(String[] args) {
		SpringApplication.run(FianlProjectHighMiddleSchoolMjhApplication.class, args);
	}

}
