import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min';
import '../css/createNotice_mjh.css';

function CreateNotice_mjh() {
  const history = useHistory();
  const goToListNotice = () => {
    history.push("/listNotice")
  }

  const [notice, setNotice] = useState({
    noticeTitle: '',
    noticeContents: '',
    noticeWriter: '',
    noticeDate: ''
  });

  const [image, setImage] = useState(null);

  // 게시글 입력 필드의 변화를 처리하는 함수
  const handleChange = (e) => {
    const { name, value } = e.target;
    setNotice({
      ...notice,
      [name]: value
    });
  };

  // 이미지 파일 입력을 처리하는 함수
  const handleImageChange = (e) => {
    setImage(e.target.files[0]); // 첫 번째 이미지 파일을 대상으로 설정 처리함
  };

  // 게시글 등록을 처리하는 함수
  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('image', image);

    // 파일이 선택된 경우에만 추가
    //  if (image) {
    //     formData.append("image", image);
    //   }
        formData.append("notice", JSON.stringify(notice));
        
        try {
          const response = await axios.post('http://localhost:9008/api/notice_mjh/upload', formData, {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          });
          alert('게시글이 등록되었습니다.')
          console.log(response.data); //서버로부터 받은 응답 데이터를 콘솔에 출력
          history.push("/listNotice_mjh"); // 등록 성공 시 목록으로 이동
        } catch (error) {
          console.error('게시글 등록 실패', error);
          alert('게시글 등록에 실패했습니다.');
    }

  }
  const handleKeyDown = (e) => {
    const adminText = e.target;
  
    // Enter 키가 눌렸을 때 줄바꿈을 허용
    if (e.key === 'Enter') {
      // 기본 동작을 방지하지 않음
      return; 
    }
  

  };
  
  
  
  return (
    <div className='createNoticeWrapper_mjh'>
      <h1>공지글 쓰기</h1>
      <form onSubmit={handleSubmit}>
        <div className='noticeInputWrapper_mjh'>
          {/* 각 입력 필드에 대한 입력 컨트롤을 렌더링하고, 변화를 handleChange합니다. */}
          <div className='createNoticeTitleWrapper_mjh'>
          <label>제목</label>
          <div>
            <input  className='createNoticeTitle_mjh' type="text" name='noticeTitle' placeholder='제목' value={notice.noticeTitle} onChange={handleChange} />
            </div>
          </div>
          <div className='createNoticeContentsWrapper_mjh'>
          <label>내용</label>
          <div>
            <textarea className='createNoticeContents_mjh' name="noticeContents" placeholder='내용' value={notice.noticeContents} onChange={handleChange} onKeyDown={handleKeyDown} style={{height: '400px', whiteSpace: 'pre-wrap'}}></textarea>
          </div>
          </div>
          <div className='createNoticeETCWrapper_mjh'>
          <label>작성자</label>
          <div>
            <input className='createNoticeWriter_mjh' type="text" name="noticeWriter" placeholder='작성자' value={notice.noticeWriter} onChange={handleChange} />
          </div>
          <label>작성일</label>
          <div>
            <input className='createNoticeDate_mjh' type="Date" name="noticeDate" placeholder='작성일' value={notice.noticeDate} onChange={handleChange} />
          </div>
          <br />
          {/* 이미지 파일 선택을 위한 입력 필드 */}
          <div className=''>
          <input type="file" onChange={handleImageChange} />
          </div>
        </div>
        <br />
        <div className='createNoticeButtonWrapper_mjh'>
          <button className='createNoticeBtn1_mjh' type='submit'>등록</button>
          <button className='createNoticeBtn2_mjh' type='reset' onClick={goToListNotice}>취소</button>
        </div>
        </div>
      </form>
    </div>
  );
}

export default CreateNotice_mjh;