import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import axios from 'axios';
import '../css/detailNotice_mjh.css';

function DetailNotice_mjh() {
    const [notice, setNotice] = useState({});

    const { noticeNumber } = useParams();

    const history = useHistory();

    useEffect(() => {
        const fetchNotice = async () => {
            try {
                const response = await axios.get(`http://localhost:9008/api/notice_mjh/${noticeNumber}`);
                setNotice(response.data);
            } catch (error) {
                console.log(error);
            }
        }
        fetchNotice();
    }, [noticeNumber]);

    const handleDelete = async (noticeNumber) => {
        if (window.confirm("게시글을 삭제하시겠습니까?")) {
            try {
                await axios.delete(`http://localhost:9008/api/notice_mjh/${noticeNumber}`);
                alert('게시글이 삭제되었습니다.');
                // 삭제 성공 후, 게시글 목록에서 해당 게시글을 제거합니다.
                history.push('/listNotice_mjh');
                setNotice(notice.filter(notice => notice.noticeNumber !== noticeNumber));
            } catch (error) {
                console.error("게시글 삭제 실패", error);
            }
        }
    };

    const goToNoticeList = () => {
        history.push('/listNotice_mjh');
    };
    const goToNoticeEdit = () => {
        history.push(`/editNotice_mjh/${noticeNumber}`);
    };

    return (
        <div className='detailNotice_mjh'>
            <h1> 공지사항 </h1>
            <div className='h1_underLine_mjh'></div>
            <button className='detailNoticeButton1_mjh' onClick={goToNoticeList}>글 목록으로</button>
            <div>
                <h2 style={{ textAlign: 'center' }}>{notice.noticeTitle} </h2>
                <div className='Writer_Date_Wrapper_mjh'>
                    <span className='detailNoticeContentWriter_mjh'>작성자 : {notice.noticeWriter}</span>
                    <span className='detailNoticeContentDate_mjh'>작성일 : {notice.noticeDate}</span>
                </div>
            </div>
            <div className='detailNoticeContentBox_mjh'>
                <p className='detailNoticeContent_mjh'>
                    {notice.imagePath && <img className='detailNoticeContentImg_mjh' src={notice.imagePath} alt='Notice' />}
                    <p style={{ whiteSpace: 'pre-wrap' }}>{notice.noticeContents}
                    </p>
                </p>
            </div>

            <div className='detailNoticeButtons_mjh'>
                {/* <button className='detailNoticeButton2_mjh' onClick={goToNoticeEdit}>수정</button>         */}
                <button className='detailNoticeBtnEdit_mjh' onClick={goToNoticeEdit}>수정</button>
                <button className='detailNoticeBtnDel_mjh' onClick={() => handleDelete(notice.noticeNumber)}>글 삭제</button>
            </div>
        </div>
    );
}

export default DetailNotice_mjh;