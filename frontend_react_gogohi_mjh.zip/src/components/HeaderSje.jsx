import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import "../css/header_sje.css";

function HeaderSje() {
    const [expanded, setExpanded] = useState(false);

    const handleToggle = () => {
        setExpanded(!expanded);
    };

    const handleClose = () => {
        setExpanded(false);
    };

    return (
        <div id='header-sje'>
            <Navbar expand="lg" className="navbar" expanded={expanded}>
                <div className='content'>
                    <Navbar.Brand className='logo' as={Link} to="/main" onClick={handleClose}>
                        <img src="images/school_sje.svg" alt="logo" />
                        하이중학교
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" onClick={handleToggle} />
                    <div className='contents'>
                        <Navbar.Collapse id="responsive-navbar-nav">
                        <div className='menu'>
                            <Nav className="me-auto">
                                <Nav.Link as={Link} to="/features" onClick={handleClose}>학교소개</Nav.Link>
                                <NavDropdown title="정보마당" id="collapsible-nav-dropdown" className='nav-dropdown'>
                                    <NavDropdown.Item as={Link} to="/action/3.1" onClick={handleClose}>학교 알림이</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/listCounsel" onClick={handleClose}>진학 상담 게시판</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/action/3.3" onClick={handleClose}>진학 학교 추천</NavDropdown.Item>
                                </NavDropdown>
                                <NavDropdown title="소통마당" id="collapsible-nav-dropdown" className='nav-dropdown'>
                                    <NavDropdown.Item as={Link} to="/listNotice_mjh" onClick={handleClose}>공지사항</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/action/3.2" onClick={handleClose}>학생 자유게시판</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/action/3.3" onClick={handleClose}>학부모 자유게시판</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/postList_sje" onClick={handleClose}>교직원 자유게시판</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/action/3.3" onClick={handleClose}>문의하기</NavDropdown.Item>
                                </NavDropdown>
                                <NavDropdown title="후원마당" id="collapsible-nav-dropdown" className='nav-dropdown'>
                                    <NavDropdown.Item as={Link} to="/action/3.1" onClick={handleClose}>후원 통합페이지</NavDropdown.Item>
                                    <NavDropdown.Divider />
                                    <NavDropdown.Item as={Link} to="/infoPayment_mjh" onClick={handleClose}>학교 사랑 후원결제</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/index_sje" onClick={handleClose}>졸업생 동문 후원결제</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/action/3.4" onClick={handleClose}>장학기금 후원결제</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/action/3.4" onClick={handleClose}>기업 후원결제</NavDropdown.Item>
                                </NavDropdown>
                                <Nav.Link as={Link} to="/features" onClick={handleClose}>자주묻는질문</Nav.Link>
                                <Nav.Link as={Link} to="/location" onClick={handleClose}>찾아오시는길</Nav.Link>
                            </Nav>
                        </div>
                                <div className='login'>
                                    <Nav.Link as={Link} to="/login" onClick={handleClose}>로그인 | 회원가입</Nav.Link>
                                </div>
                        </Navbar.Collapse>
                    </div>
                </div>
            </Navbar>
        </div>
    );
}

export default HeaderSje;
