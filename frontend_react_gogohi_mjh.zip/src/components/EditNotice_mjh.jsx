import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import '../css/editNotice_mjh.css';

function EditNotice_mjh({match}) {

    const[notice, setNotice] = useState({
        noticeTitle:'',
        noticeContents:'',
        noticeDate:'',
        noticeWriter:'관리자'
    });

    const[image, setImage] = useState(null);

    const history = useHistory();

    const goToListNotice_mjh = () =>{
        history.push("/listNotice_mjh")
    }
    useEffect(()=>{
        const fetchNoticeData = async() => {
            try {
                const response = await axios.get(`http://localhost:9008/api/notice_mjh/${match.params.id}`);
                setNotice({
                    noticeTitle: response.data.noticeTitle,
                    noticeContents: response.data.noticeContents,
                    noticeDate: response.data.noticeDate,
                    noticeWriter: response.data.noticeWriter
                });
            } catch (error) {
                console.error("게시글 정보를 불러오는데 실패했습니다.",error);
            }
        }
        fetchNoticeData();
    }, [match.params.id]);

    const handleChange = (e) =>{
        const{name, value} = e.target;
        setNotice({
            ...notice,
            [name]: value
        });
    };

    const handleImageChange = (e) => {
        setImage(e.target.files[0]);
    };

    const handleSubmit = async(e) => {
        e.preventDefault();
        const formData = new FormData;
        formData.append('image', image);
        formData.append('notice',JSON.stringify(notice));

        try {
            await axios.put(`http://localhost:9008/api/notice_mjh/update/${match.params.id}`, formData, { 
                headers:{
                    'Content-Type': 'multipart/form-data'
                }
            });
            alert('게시글이 성공적으로 수정되었습니다!');
            history.push('/listNotice_mjh');
        } catch (error) {
            console.error('게시글 수정 실패', error);
            alert('게시글 수정이 실패했습니다!')
        }
    }

    return (
        <div className='editNoticeWrapper_mjh'>
            <h2>게시글 수정</h2>
            <div className='editNotice_mjh'>
            <form onSubmit={handleSubmit}>
                <div className='editNoticeTitle_mjh'>
                    <label>제목</label>
                    <input type="text" name="noticeTitle" placeholder='제목' value={notice.noticeTitle} onChange={handleChange} />
                </div>
                <br />
                <div className='editNoticeContents_mjh'>
                    <label>내용</label>
                <textarea name="noticeContents" placeholder='내용' value={notice.noticeContents} onChange={handleChange}></textarea>
                    </div>
                <div>
                <br />
                    <label>수정일:{notice.noticeDate}</label>
                <input type="date" name='noticeDate' value={notice.noticeDate}  onChange={handleChange}/>
                <br />
                <label>작성자 :</label>
                    <label name="noticeWriter" value={notice.noticeWriter} >{notice.noticeWriter}</label>
                    </div>
                {/* <input type="file" onChange={handleImageChange} /> */}
                <br />
                <div className='editNoticeBtn_mjh'>
                <button type='submit'>수정완료</button>
                <button onClick={goToListNotice_mjh}>취소</button>
                </div>
            </form>
            </div>
        </div>
    );
}

export default EditNotice_mjh;