// 필요한 React 기능과 라이브러리를 임포트합니다.
import React, { useEffect, useState } from 'react';
import axios from 'axios';  // 서버와 HTTP 통신을 위해 axios 라이브러리를 사용합니다.
import { useLocation } from 'react-router-dom';  // URL 쿼리 문자열에 접근하기 위해 useLocation 훅을 사용합니다.

// Payment 함수형 컴포넌트를 정의합니다.
function Payment_mjh_e() {
  // 결제 데이터를 저장할 상태 변수와 상태 설정 함수를 선언합니다.
  const [paymentData, setPaymentData] = useState({});
  // 현재 위치 정보를 저장하는 location 객체를 useLocation 훅을 사용하여 가져옵니다.
  const location = useLocation();

  // 컴포넌트 마운트 시 한 번만 실행되는 useEffect 훅입니다.
  useEffect(() => {
    const IMP = window.IMP;  // 아임포트 결제 서비스 객체를 window 전역 객체에서 가져옵니다.
    IMP.init("imp78743224");  // IMP 객체를 초기화하고 가맹점 식별코드를 설정합니다.

    // URL에서 쿼리 파라미터를 읽어들여 옵니다.
    const query = new URLSearchParams(location.search);
    // 결제 금액을 가져와서 적절히 포맷팅합니다. 1000단위로 콤마를 찍고, 끝에 '원'을 붙입니다.
    const formattedAmount = query.get('amount') ? Intl.NumberFormat('ko-KR').format(query.get('amount')) + "원" : "0원";
    // 읽어들인 쿼리 파라미터를 이용하여 paymentData 상태를 설정합니다.
    setPaymentData({
      name: query.get('name'),
      amount: formattedAmount,
      buyer_email: query.get('buyer_email'),
      buyer_name: query.get('buyer_name'),
      buyer_tel: query.get('buyer_tel'),
      buyer_addr: query.get('buyer_addr'),
      buyer_postcode: query.get('buyer_postcode')
    });
  }, [location.search]);

  // 결제 처리를 위한 함수입니다.
  const handlePayment = () => {
    const IMP = window.IMP;  // 결제 모듈 객체를 가져옵니다.
    // request_pay 함수를 호출하여 결제 프로세스를 시작합니다.
    IMP.request_pay({
      pg: "html5_inicis",  // 결제 게이트웨이를 지정합니다.
      pay_method: "card",  // 결제 방법을 지정합니다.
      merchant_uid: `merchant_${new Date().getTime()}`,  // 주문 식별번호를 생성합니다.
      ...paymentData,  // 위에서 설정한 결제 데이터를 펼칩니다.
      amount: paymentData.amount.replace(/원|,/g, ''), // 결제 금액에서 '원'과 콤마를 제거합니다.
      m_redirect_url: "/paymentSuccess"  // 결제 성공 후 리다이렉트할 URL을 지정합니다.
    }, function(rsp) {
      if (rsp.success) {
        // 결제가 성공했다면 서버에 결제 정보를 전송합니다.
        axios.post('http://localhost:9008/api/payment/process', {
          imp_uid: rsp.imp_uid,  // 결제 고유 번호
          merchant_uid: rsp.merchant_uid,  // 주문 번호
          pay_amount: rsp.paid_amount,  // 결제 금액
          apply_num: rsp.apply_num,  // 카드 승인번호
          per_time: new Date()  // 현재 시간
        }, {
          headers: { 'Content-Type': 'application/json' }  // 요청 헤더에 콘텐츠 타입을 지정합니다.
        }).then(response => {
          // 응답 성공 시 결제 성공 페이지로 이동합니다.
          window.location.href = "/paymentSuccess";
        }).catch(error => {
          // 오류 발생 시 콘솔에 오류를 출력합니다.
          console.error('결제 정보 전송 에러', error);
        });
      } else {
        // 결제 실패 시 사용자에게 실패 메시지를 알립니다.
        alert(`결제 실패: ${rsp.error_msg}`);
      }
    });
  };

  // 컴포넌트의 JSX 구조를 반환합니다.
  return (
    <div>
      <h2>후원 정보 확인</h2>
      <ul>
        <li>상품명: {paymentData.name}</li>
        <li>결제 금액: {paymentData.amount}</li>
        <li>구매자 이메일: {paymentData.buyer_email}</li>
        <li>구매자 이름: {paymentData.buyer_name}</li>
        <li>구매자 연락처: {paymentData.buyer_tel}</li>
        <li>구매자 주소: {paymentData.buyer_addr}</li>
        <li>구매자 우편번호: {paymentData.buyer_postcode}</li>
      </ul>
      <button onClick={handlePayment}>후원하기</button>
    </div>
  );
}

export default Payment_mjh_e;  // Payment 컴포넌트를 기본으로 내보내기 설정합니다.
