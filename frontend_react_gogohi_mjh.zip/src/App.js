import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { useLocation } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.css';
import HeaderSje from './components/HeaderSje';
import FooterSje from './components/FooterSje';
import CreateCounseling_mjh from "./components/CreateCounseling_mjh";
import ListCounseling_mjh from "./components/ListCounseling_mjh";
import DetailCounseling_mjh from "./components/DetailCounseling_mjh";
import EditCounseling_mjh from "./components/EditCounseling_mjh";
import CreateNotice_mjh from "./components/CreateNotice_mjh";
import ListNotice_mjh from "./components/ListNotice_mjh";
import InfoPayment_mjh from "./components/InfoPayment_mjh";
import Main_sje from "./components/Main_sje";
import Location_sje from "./components/Location_sje";
import Payment_mjh from "./components/Payment_mjh";
import DetailNotice_mjh from "./components/DetailNotice_mjh";
import PostListSje from "./components/PostListSje";
import CreatePost_sje from "./components/CreatePost_sje";
import Payment_sje from "./components/Payment_sje";
import Index_sje from "./components/Index_sje";
import PostDetail_sje from "./components/PostDetail_sje";
import EditNotice_mjh from "./components/EditNotice_mjh";

function App() {
  const location = useLocation();
  const hideHeaderFooter = location.pathname === "/";
 
  return (
      <div>
      <HeaderSje/>
        <Switch>
          {/* 민지홍 */}
          <Route path="/createCounsel" component={CreateCounseling_mjh} />
          <Route path="/listCounsel" component={ListCounseling_mjh} />
          <Route path="/detailCounsel/:counselingNumber" component={DetailCounseling_mjh} />
          <Route path="/editCounsel/:counselingNumber" component={EditCounseling_mjh} />
          <Route path="/createNotice_mjh" component={CreateNotice_mjh} />
          <Route path="/listNotice_mjh" component={ListNotice_mjh} />
          <Route path="/detailNotice/:noticeNumber" component={DetailNotice_mjh} />
          <Route path="/editNotice_mjh/:noticeNumber" component={EditNotice_mjh} />
          <Route path="/infoPayment_mjh" component={InfoPayment_mjh} />
          <Route path="/payment_mjh" component={Payment_mjh} />

           {/* 서정은 */}
          <Route path='/main' component={Main_sje}/>
          <Route path='/location_sje' component={Location_sje}/>
          <Route path="/postList_sje" component={PostListSje} />{/* 교직원 게시판 */}
          <Route path="/postsSje" component={CreatePost_sje} />
          <Route path="/payment_sje" component={Payment_sje} />
          <Route path="/index_sje" component={Index_sje} />
          <Route path="/posts_sje/:boardNumber" component={PostDetail_sje} />
          
        </Switch>
        <FooterSje />
      </div>
      
  )
}
const AppWrapper = () => (
  <Router>
    <App />
  </Router>
);

export default AppWrapper;