# -*- coding: utf-8 -*-
# 필요한 라이브러리 및 모듈 가져오기
from urllib import request  # 웹에서 데이터를 요청하기 위한 모듈
import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
import cx_Oracle  # Oracle 데이터베이스와의 연결을 위한 모듈
import numpy as np  # 배열 및 수치 계산을 위한 모듈
from flask_cors import CORS  # Flask 애플리케이션에서 CORS(Cross-Origin Resource Sharing)를 허용하기 위한 모듈
from pdf2image import convert_from_bytes  # PDF를 이미지로 변환하기 위한 모듈
import easyocr  # OCR(Optical Character Recognition)을 수행하기 위한 모듈
import cv2  # 이미지 처리 및 분석을 위한 OpenCV 모듈
from flask import Flask, request, jsonify  # Flask 애플리케이션, 요청 처리, JSON 응답을 위한 모듈

# Flask 애플리케이션 인스턴스 생성
app = Flask(__name__)
CORS(app)  # 애플리케이션에 CORS 허용 (다른 도메인에서 요청을 허용)

# Oracle DB 연결 설정 (데이터베이스와 연결을 위한 설정)
dsn = cx_Oracle.makedsn("localhost", 1521, service_name="orcl")
connection = cx_Oracle.connect(user="hi1234", password="hi1234", dsn=dsn)

# 이미지 전처리 함수 (OCR 성능을 향상시키기 위해 이미지의 불필요한 부분을 처리)
def preprocess_image(image):
    # 이미지를 그레이스케일로 변환
    gray = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2GRAY)
    # 이미지를 블러링 처리하여 노이즈 제거
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    # 임계값 처리로 이미지에서 텍스트를 더 잘 인식하도록 이진화
    _, thresh = cv2.threshold(blurred, 150, 255, cv2.THRESH_BINARY_INV)
    return thresh

# OCR 결과 후처리 함수 (텍스트 인식 오류를 보정)
def postprocess_ocr_text(text):
    # 인식된 텍스트의 잘못된 부분을 수정하기 위한 사전 정의된 보정 목록
    corrections = {
        '시용시': '시흥시',  # '시용시'를 '시흥시'로 수정
        '새씩고등학교': '새싹고등학교',  # '새씩고등학교'를 '새싹고등학교'로 수정
        '기홍구': '기흥구',  # '기홍구'를 '기흥구'로 수정
        '대야로 568번길 1': '대야로 568번길'  # '대야로 568번길 1'을 '대야로 568번길'로 수정 (불필요한 번호 제거)
    }

    # 사전 정의된 오류를 순회하며 텍스트를 교정
    for wrong, correct in corrections.items():
        text = text.replace(wrong, correct)

    # 번길 끝에 불필요하게 '1'이 붙는 경우 이를 제거하는 로직
    if '번길' in text and text[-1].isdigit() and text.split()[-1] == '1':
        text = text.rsplit(' ', 1)[0]  # 마지막에 있는 '1'을 제거

    return text

# PDF 파일을 이미지로 변환하는 함수 (바이트 데이터에서 PDF를 처리)
def convert_pdf_to_images_from_bytes(pdf_bytes):
    poppler_path = r'C:\Program Files\poppler-23.11.0\Library\bin'  # Poppler의 실행 파일 경로 (PDF 변환에 필요)
    return convert_from_bytes(pdf_bytes, 600, poppler_path=poppler_path)  # PDF를 해상도 600dpi로 이미지로 변환

# EasyOCR을 사용하여 이미지에서 텍스트 추출하는 함수 (이미지 전처리 후 OCR 수행)
def extract_text_from_image(image):
    reader = easyocr.Reader(['ko', 'en'])  # 한국어와 영어를 인식할 수 있는 EasyOCR 리더 생성
    preprocessed_image = preprocess_image(image)  # 이미지 전처리 수행
    result = reader.readtext(preprocessed_image, detail=0)  # 텍스트 인식 (세부 정보를 제외한 단순 텍스트만 추출)
    return [postprocess_ocr_text(line) for line in result]  # 인식된 텍스트에 대해 후처리 적용

# 추출한 텍스트 데이터를 Oracle DB에 삽입하는 함수
def insert_data_to_oracle(data):
    cursor = connection.cursor()  # 데이터베이스 커서 생성 (SQL 실행 준비)

    # Oracle DB에 삽입할 SQL 쿼리 (학교 정보를 저장)
    insert_sql = """
        INSERT INTO K_HIGH_SCHOOL (ID, FOUND_DIV_NM, FACLT_NM, TELNO, REFINE_LOTNO_ADDR, REFINE_ROADNM_ADDR, OCR_RANK)
        VALUES (K_HIGH_SCHOOL_SEQ.NEXTVAL, :found_div_nm, :faclt_nm, :telno, :lotno_addr, :roadnm_addr, :ocr_rank)
    """

    try:
        # 데이터가 비어 있지 않은 경우만 필터링
        filtered_data = [record for record in data if all(record.values())]

        if filtered_data:
            for record in data:
                print(f"DB에 삽입될 데이터: {record}")  # 삽입할 데이터 확인
            cursor.executemany(insert_sql, filtered_data)  # 여러 데이터를 한 번에 DB에 삽입
            connection.commit()  # 트랜잭션 커밋 (DB에 실제 반영)
            print(f"{len(filtered_data)}개의 데이터가 성공적으로 Oracle DB에 삽입되었습니다.")  # 성공 메시지 출력
        else:
            print("삽입할 데이터가 없습니다.")  # 데이터가 없을 경우 메시지 출력

    except cx_Oracle.DatabaseError as e:
        print(f"Oracle DB 오류: {e}")  # DB 오류 발생 시 메시지 출력
        connection.rollback()  # 오류 발생 시 트랜잭션 롤백 (변경 사항 취소)

    finally:
        cursor.close()  # 커서 닫기

# PDF에서 텍스트를 추출하고, 이를 Oracle DB에 삽입하는 함수
def process_pdf_and_insert_to_db(pdf_bytes):
    images = convert_pdf_to_images_from_bytes(pdf_bytes)  # PDF 파일을 이미지로 변환

    extracted_data = []  # 추출된 데이터를 저장할 리스트
    current_row = {}  # 현재 처리 중인 행의 데이터를 저장할 딕셔너리

    for image in images:
        text_lines = extract_text_from_image(image)  # 이미지에서 텍스트 추출

        # 추출된 텍스트 라인별로 처리
        for line in text_lines:
            if "공립" in line or "사립" in line:
                # 새로운 학교 정보를 인식하면 현재 행을 데이터 리스트에 추가하고 새로 시작
                if current_row:
                    extracted_data.append(current_row)
                    current_row = {}

                current_row['found_div_nm'] = line.strip()  # 학교 구분(공립/사립) 정보 저장

            elif len(current_row) == 1:
                current_row['faclt_nm'] = line.strip()  # 학교 이름 정보 저장

            elif len(current_row) == 2:
                current_row['telno'] = line.strip()  # 전화번호 정보 저장

            elif len(current_row) == 3:
                current_row['lotno_addr'] = line.strip()  # 지번 주소 정보 저장

            elif len(current_row) == 4:
                current_row['roadnm_addr'] = line.strip()  # 도로명 주소 정보 저장

            elif len(current_row) == 5:
                current_row['ocr_rank'] = line.strip()  # 순위 정보 저장
                extracted_data.append(current_row)  # 완성된 행을 데이터 리스트에 추가
                current_row = {}  # 새로운 행을 위한 초기화

    if current_row:
        extracted_data.append(current_row)  # 마지막으로 남은 데이터를 추가

    insert_data_to_oracle(extracted_data)  # 추출된 데이터를 Oracle DB에 삽입

# PDF 파일을 업로드하고 처리하는 API 엔드포인트
@app.route('/upload', methods=['POST'])
def upload_pdf():
    if 'pdf' not in request.files:
        return jsonify({"message": "No file part"}), 400  # PDF 파일이 없을 경우 에러 메시지 반환

    file = request.files['pdf']  # 업로드된 파일 가져오기

    if file.filename == '':
        return jsonify({"message": "No selected file"}), 400  # 선택된 파일이 없을 경우 에러 메시지 반환

    process_pdf_and_insert_to_db(file.read())  # PDF 파일을 읽고 데이터 처리 수행

    return jsonify({"message": "PDF 처리 및 데이터 Insert 완료가 되었습니다!"})  # 성공 메시지 반환

# Flask 서버 실행 (디버그 모드로)
if __name__ == "__main__":
    app.run(debug=True, port=5001)