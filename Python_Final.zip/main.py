# main.py
import subprocess

def run_ocr_and_crawling():
    # 두 개의 스크립트를 동시에 실행
    subprocess.Popen(['python', 'ocr_main.py'])
    subprocess.Popen(['python', 'crawling_main.py'])

if __name__ == "__main__":
    run_ocr_and_crawling()
