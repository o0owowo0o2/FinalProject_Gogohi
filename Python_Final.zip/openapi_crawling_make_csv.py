# -*- coding: utf-8 -*-
"""
파일 이름: openapi_crawling_make_csv.py
"""

#이파일이 csv로 저장하는 파일이다.

# 필요한 라이브러리 임포트
import os
import urllib.request
import json
import datetime
import pandas as pd
pd.set_option('mode.chained_assignment', None)

# 공공데이터 포털에서 제공받은 인증키
ServiceKey = "4fac120bd5e34f6b9c24d9e4c42cac10"

# [CODE 1]
# 주어진 URL에 대해 HTTP 요청을 보내고, 그 결과를 반환하는 함수
def getRequestUrl(url):
    req = urllib.request.Request(url)
    try:
        response = urllib.request.urlopen(req)
        if response.getcode() == 200:
            print("[%s] Url Request Success" % datetime.datetime.now())
            return response.read().decode('utf-8')
    except Exception as e:
        print(e)
        print("[%s] Error for URL : %s" % (datetime.datetime.now(), url))
        return None

# [CODE 2]
# 고등학교 현황 정보를 API로 요청하여 가져오는 함수
def getSchoolInfo(pIndex, pSize):
    service_url = "https://openapi.gg.go.kr/HgschlM"
    parameters = "?Key=" + ServiceKey
    parameters += "&Type=json"
    parameters += "&pIndex=" + str(pIndex)
    parameters += "&pSize=" + str(pSize)
    url = service_url + parameters
    retData = getRequestUrl(url)

    if retData is None:
        return None
    else:
        return json.loads(retData)

# [CODE 3]
# 시설명에 따른 고등학교 구분명 분류 함수
def get_school_classification(faclt_nm):
    # 특성화고 (총 74개)
    specialized_schools = [
        "경기경영고등학교", "경기관광고등학교", "경기국제통상고등학교", "경기대명고등학교",
        "경기모바일과학고등학교", "경기물류고등학교", "경기스마트고등학교", "경기영상과학고등학교",
        "경기자동차과학고등학교", "경기폴리텍고등학교", "경기항공고등학교", "경민IT고등학교",
        "경민비즈니스고등학교", "경일관광경영고등학교", "경화여자English Business고등학교",
        "고양고등학교", "군자디지털과학고등학교", "군포e비즈니스고등학교", "근명고등학교",
        "김포제일공업고등학교", "남양주고등학교", "덕영고등학교", "동일공업고등학교", "두레자연고등학교",
        "두원공업고등학교", "매향여자정보고등학교", "발안바이오과학고등학교", "부천공업고등학교",
        "부천정보산업고등학교", "분당경영고등학교", "분당아람고등학교", "삼일고등학교",
        "삼일공업고등학교", "성남테크노과학고등학교", "성보경영고등학교", "성일정보고등학교",
        "세경고등학교", "수원공업고등학교", "수원농생명과학고등학교", "수원정보과학고등학교",
        "신일비즈니스고등학교", "안산국제비즈니스고등학교", "안산동산고등학교", "안성고등학교",
        "안양문화고등학교", "안양여자고등학교", "양일고등학교", "여강고등학교", "역곡고등학교",
        "영신여자고등학교", "옥정고등학교", "용인한국외국어대학교부설고등학교", "이산고등학교",
        "이천양정여자고등학교", "이포고등학교", "일죽고등학교", "장곡고등학교", "장호원고등학교",
        "정발고등학교", "천천고등학교", "청심국제고등학교", "평택여자고등학교", "포천고등학교",
        "한광여자고등학교", "한국디지털미디어고등학교", "한국외식과학고등학교", "한국조리과학고등학교",
        "한민고등학교", "한백고등학교", "한봄고등학교", "한빛고등학교", "한빛누리고등학교",
        "행신고등학교", "화홍고등학교"
    ]

    # 자율고 (총 3개)
    autonomous_schools = [
        "안산디자인문화고등학교", "우성고등학교", "원미고등학교"
    ]

    # 외국어고 (총 8개)
    foreign_language_schools = [
        "경기외국어고등학교", "고양외국어고등학교", "과천외국어고등학교", "김포외국어고등학교",
        "동두천외국어고등학교", "성남외국어고등학교", "수원외국어고등학교", "안중고등학교"
    ]

    # 예고 (총 5개)
    art_schools = [
        "경기예술고등학교", "경기체육고등학교", "계원예술고등학교", "고양예술고등학교", "안양외국어고등학교"
    ]

    # 비평준화 일반고/특성화고 (총 29개)
    unstandardized_specialized_schools = [
        "가온고등학교", "곤지암고등학교", "금곡고등학교", "마장고등학교", "문산수억고등학교",
        "백암고등학교", "부원고등학교", "비봉고등학교", "안화고등학교", "연천고등학교",
        "영복여자고등학교", "인덕원고등학교", "일동고등학교", "일산동고등학교", "정왕고등학교",
        "중산고등학교", "중흥고등학교", "진접고등학교", "창현고등학교", "초지고등학교",
        "판교고등학교", "평촌고등학교", "풍동고등학교", "풍생고등학교", "한광고등학교",
        "한국도예고등학교", "한국애니메이션고등학교", "함현고등학교", "화정고등학교"
    ]

    # 비평준화 일반고 (총 159개)
    unstandardized_schools = [
        "가좌고등학교", "가평고등학교", "갈매고등학교", "감일고등학교", "경기창조고등학교",
        "경화여자고등학교", "고촌고등학교", "관인고등학교", "광남고등학교", "광동고등학교",
        "광주고등학교", "광주중앙고등학교", "광탄고등학교", "교하고등학교", "구리고등학교",
        "구리여자고등학교", "군서고등학교", "금촌고등학교", "김포고등학교", "김포제일고등학교",
        "나루고등학교", "남양고등학교", "남양주다산고등학교", "남한고등학교", "능동고등학교",
        "다산고등학교", "대부고등학교", "대신고등학교", "덕계고등학교", "덕소고등학교",
        "덕정고등학교", "덕현고등학교", "도농고등학교", "동남고등학교", "동두천고등학교",
        "동두천중앙고등학교", "동탄고등학교", "동탄중앙고등학교", "동패고등학교", "동화고등학교",
        "라온고등학교", "마석고등학교", "마송고등학교", "매홀고등학교", "목감고등학교",
        "문산고등학교", "문산제일고등학교", "미사강변고등학교", "미사고등학교", "반송고등학교",
        "배곧고등학교", "백송고등학교", "별가람고등학교", "별내고등학교", "병점고등학교",
        "봉담고등학교", "봉일천고등학교", "비전고등학교", "사우고등학교", "삼광고등학교",
        "삼괴고등학교", "새솔고등학교", "서연고등학교", "서울삼육고등학교", "서해고등학교",
        "설악고등학교", "성호고등학교", "세교고등학교", "세마고등학교", "세종고등학교",
        "소래고등학교", "솔터고등학교", "송산고등학교", "송우고등학교", "송탄고등학교",
        "수택고등학교", "시흥고등학교", "시흥능곡고등학교", "시흥매화고등학교", "신장고등학교",
        "신천고등학교", "신한고등학교", "신흥고등학교", "심석고등학교", "안곡고등학교",
        "안산강서고등학교", "안성여자고등학교", "안양고등학교", "야탑고등학교", "양동고등학교",
        "양명고등학교", "양영디지털고등학교", "양주고등학교", "양주백석고등학교", "양지고등학교",
        "양평전자과학고등학교", "여주고등학교", "여주제일고등학교", "오산고등학교", "오산정보고등학교",
        "옥빛고등학교", "와부고등학교", "용문고등학교", "용인고등학교", "용인바이오고등학교",
        "용인백현고등학교", "운중고등학교", "운천고등학교", "원곡고등학교", "위례고등학교",
        "율면고등학교", "은혜고등학교", "의왕고등학교", "의정부공업고등학교", "의정부광동고등학교",
        "이천고등학교", "이천세무고등학교", "이충고등학교", "이현고등학교", "인창고등학교",
        "일산고등학교", "일산대진고등학교", "저동고등학교", "저현고등학교", "전곡고등학교",
        "정현고등학교", "주엽고등학교", "죽산고등학교", "진위고등학교", "창의경영고등학교",
        "처인고등학교", "청담고등학교", "청학고등학교", "초월고등학교", "충현고등학교",
        "태광고등학교", "태전고등학교", "토평고등학교", "파주여자고등학교", "판곡고등학교",
        "평내고등학교", "평촌경영고등학교", "평촌과학기술고등학교", "평택마이스터고등학교", "포천일고등학교",
        "풍산고등학교", "하남고등학교", "하성고등학교", "한국관광고등학교", "한국문화영상고등학교",
        "한솔고등학교", "향남고등학교", "향동고등학교", "현암고등학교", "호매실고등학교",
        "호평고등학교", "화성고등학교", "효명고등학교", "효성고등학교"
    ]

    # 마이스터고 (총 3개)
    meister_schools = [
        "경기게임마이스터고등학교", "수원하이텍고등학교", "풍덕고등학교"
    ]

    # 국제고 (총 3개)
    international_schools = [
        "고양국제고등학교", "동탄국제고등학교", "초당고등학교"
    ]

    # 과학고 (총 2개)
    science_schools = [
        "경기과학고등학교", "경기북과학고등학교"
    ]

    # 학교 구분
    if faclt_nm in specialized_schools:
        return "특성화고"
    elif faclt_nm in autonomous_schools:
        return "자율고"
    elif faclt_nm in foreign_language_schools:
        return "외국어고"
    elif faclt_nm in art_schools:
        return "예고"
    elif faclt_nm in unstandardized_specialized_schools:
        return "비평준화 일반고/특성화고"
    elif faclt_nm in unstandardized_schools:
        return "비평준화 일반고"
    elif faclt_nm in meister_schools:
        return "마이스터고"
    elif faclt_nm in international_schools:
        return "국제고"
    elif faclt_nm in science_schools:
        return "과학고"
    else:
        return "평준화 일반고"  # 기본값으로 평준화 일반고 처리

# [CODE 4]
# API로 데이터를 수집하고, 이를 CSV 파일로 저장하는 함수
def getSchoolData(pSize=100):
    pIndex = 1
    isDataEnd = False
    jsonResult = []
    result = []

    while not isDataEnd:
        jsonData = getSchoolInfo(pIndex, pSize)

        if jsonData is None:
            break

        print("응답 데이터: ", json.dumps(jsonData, indent=4, ensure_ascii=False))

        if 'HgschlM' in jsonData:
            rows = jsonData['HgschlM'][1]['row']
            total_count = jsonData['HgschlM'][0]['head'][0]['list_total_count']
            print(f"총 데이터 수: {total_count}")

            for item in rows:
                faclt_nm = item.get('FACLT_NM', '')  # 시설명
                school_classification = get_school_classification(faclt_nm)  # 고등학교 구분명

                jsonResult.append(item)
                result.append([
                    item.get('SCHOOL_DIV_NM', ''),  # 학교구분명
                    faclt_nm,  # 시설 명
                    item.get('TELNO', ''),  # 전화번호
                    item.get('REFINE_LOTNO_ADDR', ''),  # 지번주소
                    item.get('REFINE_ROADNM_ADDR', ''),  # 도로명 주소
                    item.get('REFINE_ZIP_CD', ''),  # 우편번호
                    school_classification  # 고등학교 구분명 추가
                ])

            if len(result) >= total_count:
                isDataEnd = True
            else:
                pIndex += 1
        else:
            print("응답 데이터에 'HgschlM' 키가 없습니다.")
            isDataEnd = True

    columns = ["학교구분명", "학교이름", "전화번호", "지번주소", "도로명주소", "우편번호", "고등학교 구분명"]
    result_df = pd.DataFrame(result, columns=columns)
    result_df.to_csv('./school_info.csv', index=False, encoding='euc-kr')
    print("school_info.csv 파일로 저장되었습니다.")

# [CODE 5]
# 고등학교 구분과 내신등급 정보를 추가하여 새로운 CSV 파일로 저장
def preprocessSchoolData():
    school_df = pd.read_csv('./school_info.csv', encoding='euc-kr')

    # '위도'와 '경도' 칼럼이 존재할 경우에만 삭제
    if '위도' in school_df.columns:
        school_df = school_df.drop(['위도'], axis=1)
    if '경도' in school_df.columns:
        school_df = school_df.drop(['경도'], axis=1)

    # 고등학교 구분명에 따른 내신등급을 설정하는 함수
    def assign_rank(school_classification):
        if '과학' in school_classification:
            return 1
        elif '외국어' in school_classification:
            return 2
        elif '국제' in school_classification:
            return 1
        elif '특성화' in school_classification:
            return 4
        elif '예술' in school_classification:
            return 5
        elif '체육' in school_classification:
            return 3
        elif '자율' in school_classification:
            return 2
        elif '마이스터' in school_classification:
            return 1
        else:
            return 5

    # 내신등급 칼럼 추가
    school_df['rank'] = school_df['고등학교 구분명'].apply(assign_rank)

    # 내신등급 칼럼 이름 변경
    school_df.rename(columns={'rank': '진학가능내신등급'}, inplace=True)

    # 최종 CSV 파일로 저장
    school_df.to_csv('./경기도_고등학교현황_최종.csv', encoding='euc-kr', index=False)
    print("경기도_고등학교현황_최종.csv 파일로 저장되었습니다.")

# 메인 함수 실행
if __name__ == '__main__':
    getSchoolData(pSize=100)
    preprocessSchoolData()
