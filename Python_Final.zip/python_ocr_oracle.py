# -*- coding: utf-8 -*-
# 필수 라이브러리 및 모듈 임포트
import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
import cx_Oracle  # Oracle DB에 연결하기 위한 모듈
import os  # 운영 체제 관련 작업을 수행하기 위한 모듈
import numpy as np  # 배열 및 행렬 연산을 위한 모듈
from pdf2image import convert_from_path  # PDF 파일을 이미지로 변환하는 함수
import easyocr  # OCR(문자인식)을 위한 모듈

# Oracle DB 연결 설정
# Oracle DB에 연결하기 위한 DSN(Data Source Name) 생성
dsn = cx_Oracle.makedsn("localhost", 1521, service_name="orcl")
# Oracle DB 연결 설정 (사용자 ID, 비밀번호, DSN 정보 입력)
connection = cx_Oracle.connect(user="hi1234", password="hi1234", dsn=dsn)

# 잘못된 인식된 텍스트를 수정하는 보정 사전
# OCR 결과에서 잘못 인식된 텍스트를 보정하기 위한 사전 정의
corrections = {
    '기홍구': '기흥구',  # 잘못 인식된 구명을 수정
    '새씩고등학교': '새싹고등학교',  # 학교명 오타 수정
    '백현로 745번길': '백현동 345-6번지',  # 주소 오타 수정
    '동백로 123번길': '동백동 123-4번지',  # 주소 오타 수정
    '상동로 235번길': '상동로 235번길 7',  # 주소 수정
    '소하로': '소하면',  # 주소 오타 수정
    '성남시 분당구 백현동': '성남시 분당구 백현로 745번길'  # 주소 보정
}

# 텍스트 보정 함수
# OCR로 추출된 텍스트에서 잘못된 부분을 보정하는 함수
def correct_text(text):
    # 정의된 보정 사전을 이용해 잘못된 텍스트를 올바른 텍스트로 교체
    for wrong, correct in corrections.items():
        text = text.replace(wrong, correct)
    return text  # 보정된 텍스트 반환

# PDF 파일을 이미지로 변환하는 함수
def convert_pdf_to_images(pdf_path):
    # PDF 파일을 이미지로 변환하기 위해 poppler 경로 설정 (PDF를 이미지로 변환할 때 필요)
    poppler_path = r'C:\Program Files\poppler-23.11.0\Library\bin'
    # PDF 파일을 500 DPI 해상도의 이미지로 변환하여 반환
    return convert_from_path(pdf_path, 500, poppler_path=poppler_path)

# EasyOCR을 사용하여 이미지에서 텍스트를 추출하는 함수
def extract_text_from_image(image):
    # OCR 모델 초기화, 한국어와 영어를 지원
    reader = easyocr.Reader(['ko', 'en'])
    # PIL 이미지 객체를 numpy 배열로 변환
    image_np = np.array(image)
    # 이미지에서 텍스트를 추출 (detail=0: 좌표 정보 없이 텍스트만 반환)
    result = reader.readtext(image_np, detail=0)
    # 추출된 텍스트에 대해 보정 적용
    return [correct_text(line) for line in result]

# 추출한 텍스트 데이터를 Oracle DB에 삽입하는 함수
def insert_data_to_oracle(data):
    cursor = connection.cursor()  # DB와 통신하기 위한 커서 생성
    # 데이터 삽입을 위한 SQL 구문 정의
    insert_sql = """
        INSERT INTO K_HIGH_SCHOOL (ID, FOUND_DIV_NM, FACLT_NM, TELNO, REFINE_LOTNO_ADDR, REFINE_ROADNM_ADDR, OCR_RANK)
        VALUES (K_HIGH_SCHOOL_SEQ.NEXTVAL, :found_div_nm, :faclt_nm, :telno, :lotno_addr, :roadnm_addr, :ocr_rank)
    """
    try:
        # 모든 필드가 채워진 데이터를 필터링 (빈 데이터는 제외)
        filtered_data = [record for record in data if all(record.values())]
        # 필터링된 데이터가 있을 경우에만 DB 삽입 수행
        if filtered_data:
            for record in filtered_data:
                # 삽입될 데이터를 콘솔에 출력하여 확인 (디버깅 목적)
                print(f"DB에 삽입될 데이터: {record}")
            # 데이터를 여러 개 한번에 DB에 삽입 (배치 삽입)
            cursor.executemany(insert_sql, filtered_data)
            connection.commit()  # 커밋하여 DB에 변경 사항 반영
            print(f"{len(filtered_data)}개의 데이터가 성공적으로 Oracle DB에 삽입되었습니다.")
        else:
            print("삽입할 데이터가 없습니다.")
    except cx_Oracle.DatabaseError as e:
        # DB 오류가 발생하면 오류 메시지를 출력하고 롤백
        print(f"Oracle DB 오류: {e}")
        connection.rollback()
    finally:
        cursor.close()  # 커서를 닫아 자원을 반환

# PDF에서 텍스트를 추출하고, 이를 Oracle DB에 삽입하는 함수
def process_pdf_and_insert_to_db(pdf_path):
    # PDF 파일을 이미지로 변환
    images = convert_pdf_to_images(pdf_path)
    extracted_data = []  # 추출된 데이터를 저장할 리스트
    current_row = {}  # 현재 레코드를 저장할 딕셔너리

    # 각 이미지에서 텍스트 추출 및 데이터 처리
    for image in images:
        text_lines = extract_text_from_image(image)

        # 추출된 각 줄에 대해 데이터 매핑
        for line in text_lines:
            # 설립구분(공립/사립)이 포함된 줄을 찾아 해당 레코드를 새로 시작
            if "공립" in line or "사립" in line:
                if current_row:  # 현재 레코드가 있을 경우, 리스트에 추가
                    extracted_data.append(current_row)
                    current_row = {}

                # 설립구분명 추가
                current_row['found_div_nm'] = line.strip()

            # 학교명 추가
            elif len(current_row) == 1:
                current_row['faclt_nm'] = line.strip()

            # 전화번호 추가
            elif len(current_row) == 2:
                current_row['telno'] = line.strip()

            # 지번 주소 추가
            elif len(current_row) == 3:
                current_row['lotno_addr'] = line.strip()

            # 도로명 주소 추가
            elif len(current_row) == 4:
                current_row['roadnm_addr'] = line.strip()

            # 내신등급 추가 후 레코드 완성
            elif len(current_row) == 5:
                current_row['ocr_rank'] = line.strip()
                extracted_data.append(current_row)
                current_row = {}

    # 마지막 레코드가 있다면 리스트에 추가
    if current_row:
        extracted_data.append(current_row)

    # 추출된 데이터를 DB에 삽입
    insert_data_to_oracle(extracted_data)

# 메인 실행 함수
def main():
    # 처리할 PDF 파일 경로 설정
    pdf_path = r'C:\python_pdf_choice\k_high_school_rank_add.pdf'
    # PDF 처리 및 DB 삽입 함수 호출
    process_pdf_and_insert_to_db(pdf_path)

# 스크립트가 직접 실행될 때만 main 함수를 호출
if __name__ == "__main__":
    main()