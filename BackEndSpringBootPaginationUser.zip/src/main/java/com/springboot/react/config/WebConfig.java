package com.springboot.react.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

// 백엔드 애플리케이션에 CORS 설정을 추가해야 합니다.
// Spring Boot에서는 WebMvcConfigurer를 구현하거나 @CrossOrigin 어노테이션을 사용하여
// 특정 엔드포인트 또는 전역에서 CORS를 허용할 수 있습니다.
// 예시: 전역 CORS 설정 추가

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
        		.allowedOrigins("*", "http://192.168.10.49:3000", "http://localhost:3000")
//                .allowedOrigins("http://현재PC IP 주소 입력:3000", "http://localhost:3000")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(false);
    }
    
    // 정적 리소스 핸들링을 위한 설정 메서드 오버라이드

}