// 패키지 선언
package com.springboot.react.service.impl;

// 필요한 클래스와 인터페이스를 임포트합니다.
import com.springboot.react.entity.Student;
import com.springboot.react.repository.StudentRepository;
import com.springboot.react.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

// @Service 어노테이션은 이 클래스가 스프링 컨테이너에 의해 서비스 레이어의 컴포넌트로 관리됨을 나타냅니다.
@Service
public class StudentServiceImpl implements StudentService {

    // final 키워드는 postRepository가 초기화 이후 변경되지 않음을 보장합니다.
    private final StudentRepository studentRepository;

    // @Autowired를 사용하여 Spring의 의존성 주입 기능으로 PostRepository를 주입받습니다.
    @Autowired
    public StudentServiceImpl(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    // findById 메소드는 주어진 id를 가진 Post 객체를 찾아 Optional로 반환합니다.
    @Override
    public Optional<Student> findById(Long id) {
        return studentRepository.findById(id);
    }

    // findAll 메소드는 저장된 모든 Post 객체를 리스트로 반환합니다.
//    @Override
//    public List<Student> findAll() {
//        return studentRepository.findAll();
//    }
    
    @Override
    public Page<Student> findAll(Pageable pageable) {
        return studentRepository.findAll(pageable);
    }
    
    // updatePost 메소드는 주어진 id의 Post 객체를 찾아 내용을 업데이트합니다.
    @Override
    public Student updateStudent(Long id, Student studentDetails) {
        // 만약 Post가 존재하지 않는다면 RuntimeException을 발생시킵니다.
    	Student student = studentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Post not found with id " + id));

        // Post의 제목과 내용을 업데이트합니다.
        student.setBoardTitle(studentDetails.getBoardTitle());
        student.setBoardContents(studentDetails.getBoardContents());
        // 작성자 정보는 수정하지 않습니다.

        // 업데이트된 Post 객체를 저장하고 반환합니다.
        Student updatedStudent = studentRepository.save(student);
        return updatedStudent;
    }
    
    // deletePost 메소드는 주어진 id의 Post 객체를 찾아 삭제합니다.
    @Override
    public void deleteStudent(Long id) {
        // 만약 Post가 존재하지 않는다면 RuntimeException을 발생시킵니다.
    	Student student = studentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Post not found with id " + id));
    	studentRepository.delete(student);
    }

	@Override
	public Student saveStudent(Student student) {
		// TODO Auto-generated method stub
		return studentRepository.save(student);
	}
    
}

