package com.springboot.react.service;

import com.springboot.react.entity.Contact;

public interface ContactService {


	Contact saveContact(Contact contact); // 게시글 등록 메소드
}