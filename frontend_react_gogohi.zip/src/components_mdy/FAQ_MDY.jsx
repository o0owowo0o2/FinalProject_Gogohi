import React  from "react";

import Accordion from 'react-bootstrap/Accordion';
import '../css_mdy/faq_mdy.css'; // 상대 경로 수정
import { useHistory } from 'react-router-dom';
const FAQ_MDY = () => {
  const history = useHistory(); // 브라우저 히스토리 객체


     // 홈 화면으로 이동하는 함수
     const goToPostMain = () => {
      history.push('/about_mdy'); // 홈 화면으로 라우팅
  };


  return (
    <div className="wrapperW_mdy">
    <div style={{width:'100', height:'100px'}} />
   
     
      <div className='wrapper_mdy'>
        <div className="container_mdy">
          <h2 className="faqT_mdy">FAQ</h2>
         
          
          <Accordion defaultActiveKey="100" className="qnaList_mdy">
            <Accordion.Item eventKey="0">
              <Accordion.Header className="on_header_mdy">
              <span className="titP_mdy"><img src="./resource_mdy/images/q_mdy.png" alt="q" /></span>
                <p className="tit_mdy">
                  <span >&nbsp;&nbsp; &nbsp;일반 Q 제 내신 성적으로 OO고등학교에 갈 수 있나요? 작년 OO고등학교의 커트라인이 궁금합니다.</span>
                </p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP_mdy"><img src="./resource_mdy/images/a_mdy.png" alt="a" /></span>
                <p className="answerDiv_mdy">
                  <span >합격 컷트 라인은 매년 달라집니다. </span>
                </p>
              </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="1">
              <Accordion.Header>
              <span className="titP_mdy"><img src="./resource_mdy/images/q_mdy.png" alt="q" /></span>
                <p className="tit_mdy">&nbsp;&nbsp; &nbsp;자사고&middot;외고&middot;국제고의 입학전형 시기는 언제인가요?</p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP_mdy"><img src="./resource_mdy/images/a_mdy.png" alt="a" /></span>
                <p className="answerDiv_mdy">

                  <span> 국제고는 일반고와 함께 후기전형으로 학생을 선발합니다 
                    국제고와 일반고의 고입 동시 선발은 공정하고 동등한 입학전형을 실현함으로써 입학전형에서의 사교육 가열화 및 고교 서열화 등의 문제를 완화하는데 그 목적이 있습니다</span>
                </p>
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="2">
              <Accordion.Header>
              <span className="titP_mdy"><img src="./resource_mdy/images/q_mdy.png" alt="q" /></span>
                <p className="tit_mdy">&nbsp;&nbsp; &nbsp;인증시험, 올림피아드 및 경시대회, 외국어 능력시험 성적, 영재교육원 수료 여부 등을 반영하는지요?</p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP_mdy"><img src="./resource_mdy/images/a_mdy.png" alt="a" /></span>
                <div className="answerDiv_mdy">
                  <p>반영하지 않습니다 자기주도학습전형에서는 학교생활기록부 수상실적 항목을 제외시키고 있습니다 그리고 자기소개서에도 이에 관한 사항을 기재할 수 없습니다
                  </p>
                </div>
              </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="3">
              <Accordion.Header>
              <span className="titP_mdy"><img src="./resource_mdy/images/q_mdy.png" alt="q" /></span>
                <p className="tit_mdy">&nbsp;&nbsp; &nbsp;외국어고 &middot; 국제고의 경우 1단계 내신성적 산출은 어떻게 하나요?</p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP_mdy"><img src="./resource_mdy/images/a_mdy.png" alt="a" /></span>
                <div className="answerDiv_mdy">
                1단계에서는 영어 내신성적(160점)과 출결(감점)로 선발합니다. <br/>
                영어 내신성적은 중학교 2,3학년의 원점수, 과목평균(표준편차)을 제외한 성취도 수준을 활용하여 정원의 1.5~2배수를 선발합니다.  <br/>
                -1단계 동점자 발생시 다음의 기준으로 선발합니다 <br/>
                3학년 2학기 국어, 3학년 사회, 3학년 1학기 국어,  3학년 1학기 사회, 2학년 2학기 국어, 2학년 2학기 사회,  2학년 1학기 국어, 2학년 1학기 사회의 순서로 성취도 수준을 반영하여 선발합니다.  

                </div>
              </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="4">
              <Accordion.Header>
              <span className="titP_mdy"><img src="./resource_mdy/images/q_mdy.png" alt="q" /></span>
                <p className="tit_mdy">&nbsp;&nbsp; &nbsp;외국어고 &middot; 국제고의 경우 영어 내신성적이 1등급이어야만 자기주도학습전형에 지원할 수 있나요? </p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP_mdy"><img src="./resource_mdy/images/a_mdy.png" alt="a" /></span>
                <div className="answerDiv_mdy">
                1등급이 아니어도 지원할 수 있습니다.
                자기주도학습전형에서는 제출 서류와 면접을 통해 영어 내신 이외에 자기주도학습영역(꿈과 끼 영역)과 인성영역, 학생의 발전 가능성과 잠재력을 평가하므로 학교에서 관련 교과 공부에 충실하고, 학교를 중심으로 한 다양한 비교과활동을 통해 꿈을 향한 열정과 노력의 과정, 성과를 잘 보여줄 수 있는 학생이라면 누구나 지원 가능합니다. <br/>
                내신이 다소 떨어지더라도 학습 및 진로목표가 분명하고, 핵심인성요소에 대한 활동을 지속적으로 의미 있게 해왔다면 지원할 수 있습니다. 

                </div>
              </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="5">
              <Accordion.Header>
              <span className="titP_mdy"><img src="./resource_mdy/images/q_mdy.png" alt="q" /></span>
                <p className="tit_mdy">&nbsp;&nbsp; &nbsp; 자기소개서 작성 시 감점되는 내용은 무엇인가요? </p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP_mdy"><img src="./resource_mdy/images/a_mdy.png" alt="a" /></span>
                <div className="answerDiv_mdy">
                1 본문에 영어 등 각종 인증시험 점수, 교과목의 점수·석차, 교내·외 각종 대회 입상실적, 자격증, 영재교육원 교육 및 수료 여부 등 기재 시 0점 처리합니다. <br/>
                2 또한 부모 및 친인척의 사회·경제적 지위 암시 내용, 지원자 본인의 인적 사항을 암시하는 내용 등 기재 시 학교별 기준을 마련하여 항목 배점의 10% 이상 감점처리 합니다.<br/>
                - 인증시험 및 각종 대회 입상 증빙자료를 참고자료로 제출하는 경우, 우회적·간접적인 진술에도 0점 처리<br/>
                - 평가 항목은 자기주도학습과정, 지원동기 및 진로계획, 핵심인성요소에 대한 중학교 활동실적, 인성영역 활동을 통해 느낀 점 등으로 구분<br/>

                </div>
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="6">
              <Accordion.Header>
              <span className="titP_mdy"><img src="./resource_mdy/images/q_mdy.png" alt="q" /></span>
                <p className="tit_mdy">&nbsp;&nbsp; &nbsp; 사회통합전형은 어떤 사람들이 지원할 수 있나요?  </p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP_mdy"><img src="./resource_mdy/images/a_mdy.png" alt="a" /></span>
                <div className="answerDiv_mdy">
                사회통합전형은 자율형사립고, 특수목적고(외고, 국제고, 과학고)에서 입학 정원의 일정 비율을 국가적으로 보호가 필요한 학생을 대상으로 별도로 선발하는 전형으로 기회균등전형과 사회다양성전형으로 구분됩니다.<br/>

                - 기회균등전형과 사회다양성전형 대상자의 경우, 시·도별로 상이하므로 각 시·도교육청의 고등학교 입학전형 기본계획을 참고하시기 바랍니다(고입정보포털사이트 , 고교 입시정보 ,시·도별입시정보) <br/>

                </div>
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="7">
              <Accordion.Header>
              <span className="titP_mdy"><img src="./resource_mdy/images/q_mdy.png" alt="q" /></span>
                <p className="tit_mdy">&nbsp;&nbsp; &nbsp;사회통합전형대상자는 반드시 사회통합전형으로만 지원해야 하나요? 
                </p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP_mdy"><img src="./resource_mdy/images/a_mdy.png" alt="a" /></span>
                <div className="answerDiv_mdy">
                반드시 사회통합전형으로만 지원해야 하는 것은 아닙니다.<br/>
              사회통합전형이 아닌 일반전형으로 지원하기를 희망하는 경우, 일반전형으로도 지원이 가능합니다.  <br/>

                </div>
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="8">
              <Accordion.Header>
              <span className="titP_mdy"><img src="./resource_mdy/images/q_mdy.png" alt="q" /></span>
                <p className="tit_mdy">&nbsp;&nbsp; &nbsp;외국어고 학과별 진학 시 전공어를 어느 정도 학습해야 입학 가능한가요? 

                </p>
              </Accordion.Header>
              <Accordion.Body>
              <span className="ansP_mdy"><img src="./resource_mdy/images/a_mdy.png" alt="a" /></span>
                <div className="answerDiv_mdy">
                입학전형에서는 전공어 능력을 평가하지 않습니다. 따라서 전공어 습득 정도에 따라 합격이 좌우되지 않습니다. <br/>
                전공어 학습은 고등학교 입학 후 열심히 하면 됩니다. 

                </div>
              </Accordion.Body>
            </Accordion.Item>


          


          </Accordion>

          <div className="pagination_mdy">
              &lt; 
             <a href="#"> 1 </a>
             <a href="#"> 2 </a>
             <a href="#"> 3 </a>
    
             &gt;
          </div>

          
         






        </div>
        {/* container */}
      </div>
      {/* wrapper */}
     
    </div>
    // wrapperW 
   
           
  );
};

export default FAQ_MDY;
