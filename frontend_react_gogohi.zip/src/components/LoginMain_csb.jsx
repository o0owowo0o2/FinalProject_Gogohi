import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';
import '../css_csb/LoginMain_csb.css'; // CSS 파일 import

function LoginMain_csb() {
    const history = useHistory();
    const memberData = JSON.parse(localStorage.getItem("loggedInMember"));
    const [memberId, setMemberId] = useState(memberData ? memberData.memberId : '');
    const [member, setMember] = useState(null); // 추가된 상태

    useEffect(() => {
        // 초기 로딩 시 회원 정보를 가져옵니다.
        if (memberId) {
            axios.get(`http://localhost:9008/api/members/${memberId}`)
                .then(response => {
                    setMember(response.data); // 받아온 데이터를 상태에 저장합니다.
                })
                .catch(error => console.error('회원 데이터 가져오기 오류:', error));
        }
    }, [memberId]);

    const handleLogout = () => {
        localStorage.removeItem("loggedInMember");
        alert("로그아웃 되었습니다");
        window.location.href = '/';
    };

    const handleDeleteAccount = async () => {
        // 회원 탈퇴 확인 메시지
        const confirmDelete = window.confirm("정말로 회원 탈퇴를 하시겠습니까?");
        if (confirmDelete) {
            try {
                await axios.delete(`http://localhost:9008/api/members/${memberId}`);
                alert("회원 탈퇴가 완료되었습니다.");
                localStorage.removeItem("loggedInMember");
                window.location.href = '/';
            } catch (error) {
                console.error("회원 탈퇴 오류:", error);
                alert("회원 탈퇴 중 오류가 발생했습니다.");
            }
        }
    };

    const goToMain = () => {
        history.push('/');
    };

    const goToEditMember = () => {
        if (memberId) {
            history.push(`/edit_csb/${memberId}`); // 수정된 부분: memberId를 포함하여 이동
        } else {
            alert("회원 정보를 불러올 수 없습니다.");
        }
    };

    return (
        <div className="login-main_csb3">
            <h1 className="login-header_csb3">내 정보</h1>
            {member ? (
                <div className="member-details_csb3">
                    <img 
                        src={member.imagePath || "http://localhost:9008/react_images/user.png"} 
                        alt='프로필 이미지' 
                        className="profile-image_csb3" 
                    />
                    <p>아이디: {member.memberId}</p>
                    <p>이름: {member.memberName}</p>
                    <p>전화번호: {member.memberPhone}</p>
                    <p>주소: {member.address}</p>
                    <p>성별: {member.gender}</p>
                </div>
            ) : (
                <p>로그인되지 않았습니다.</p>
            )}
            <button onClick={handleLogout} className="logout-button_csb3">로그아웃</button>
            <button onClick={goToMain} className="main-button_csb3">메인으로 이동</button>
            <button onClick={goToEditMember} className="main-button_csb3">회원 정보 수정</button>
            <button onClick={handleDeleteAccount} className="main-button_csb3">회원 탈퇴</button>
        </div>
    );
}

export default LoginMain_csb;
