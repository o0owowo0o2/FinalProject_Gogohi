import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import PaginationSje from './PaginationSje';
import '../css/schoolserch_sje.css';
import { Link } from 'react-router-dom';

function SchoolSearch_sje() {

    const [datas, setDatas] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const postsPerPage = 15;
    const [totalPages, setTotalPages] = useState(0);
    const [isLoaded, setIsLoaded] = useState(false);

    // 검색 관련 상태 변수
    const [searchTerm, setSearchTerm] = useState('');
    const [searchQuery, setSearchQuery] = useState('');

    const [isOpen, setIsOpen] = useState(false);

    const fetchDatas = useCallback(async () => {
        setIsLoaded(false);
        try {
            const response = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/schools`, {
                params: {
                    page: currentPage - 1,
                    size: postsPerPage,
                    rank: searchQuery || null,  // 검색어가 있으면 rank로 요청
                },
            });
            setDatas(response.data.content);
            setTotalPages(response.data.totalPages);
            setIsLoaded(true);
        } catch (error) {
            console.error("데이터 조회 에러", error);
            setIsLoaded(true);
        }
    }, [currentPage, postsPerPage, searchQuery]);

    useEffect(() => {
        fetchDatas();
    }, [fetchDatas]);

    const handleSearch = () => {
        setSearchQuery(searchTerm);
        setCurrentPage(1);
    };

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    // 버튼을 눌렀을 때 드롭다운 상태를 변경하는 함수
    const toggleDropdown = () => {
        setIsOpen(!isOpen);
    };

    return (
        <div id='schoolSearch_sje'>
            <div style={{ width: '100%', height: '56px' }} />
            <div className='wrapper'>
                <h1 className='header'>진학 학교 추천</h1>
                <hr />
                <div className='content'>
                    <div className='contents'>
                        <p>하이중학교는 독자적인 스쿨 매칭 시스템을 활용하여 학생 개개인의 적성과 잠재력을 체계적으로 분석하고, <br />자신에게 맞는 고등학교를 추천함으로써 학생들이 자신의 진로를 올바르게 설계할 수 있도록 지원하고 있습니다. </p><br /><p> 진학 학교 추천 서비스를 이용하기 위해서는 <Link to="/bigdata">빅데이터 크롤링</Link>이 필요합니다.</p>
                    </div>                   
                    <br />
                    <div className='search'>
                        <input 
                            type="text" 
                            placeholder='내신등급' 
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                        <button className='search-b' onClick={handleSearch}>
                            <img src="images_sje/search_icon_s.svg" alt="검색" />
                        </button>
                    </div>
                    <div className='school'>
                        <ul>
                            {datas.map(school => (
                                <li key={school.id}>
                                    <h4>{school.facltNm}</h4>
                                    <p>{school.refineLotnoAddr}</p>
                                    <p>{school.telno}</p>
                                    <p>{school.schoolClassification}</p>
                                    <p>진학가능 내신등급 : {school.openApiRank}</p>
                                </li>
                            ))}
                        </ul>
                    </div>
                    <div className='pagination'>
                        <PaginationSje currentPage={currentPage} totalPages={totalPages} paginate={paginate} />
                    </div>
                    <br />
                    <button onClick={toggleDropdown} className="toggle-button">
                    {isOpen ? '진학 학교 추천 분석/통계 현황' : '진학 학교 추천 분석/통계 현황'}
                        <img
                            src={isOpen ? "images_sje/down.svg" : "images_sje/up.svg"}
                            alt={isOpen ? "닫기" : "열기"}
                            className="toggle-icon"
                        />
                    </button>
                    <div className='imgdata'>
                        <div className='data'>
                            <div className={`dropdown-container ${isOpen ? 'open' : ''}`}>
                                <img className='img2' src="images_sje/school_local_count.png" alt="자료2" />
                                <img className='img3' src="images_sje/school_type.png" alt="자료3" />
                                <img className='img1' src="images_sje/gogohi.jpg" alt="자료1" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default SchoolSearch_sje;
