import React, { useState } from 'react';
import '../css/schoolserch_sje.css';

function SchoolSearch_sje() {
    const [isOpen, setIsOpen] = useState(false);

    // 버튼을 눌렀을 때 드롭다운 상태를 변경하는 함수
    const toggleDropdown = () => {
        setIsOpen(!isOpen);
    };

    return (
        <div id='schoolSearch_sje'>
            <div style={{ width: '100%', height: '56px' }} />
            <div className='wrapper'>
                <h1 className='header'>진학 학교 추천</h1>
                <hr />
                <div className='content'>
                    <div className='contents'>
                        <p>하이중학교는 독자적인 스쿨 매칭 시스템을 활용하여 학생 개개인의 적성과 잠재력을 체계적으로 분석하고, <br />자신에게 맞는 고등학교를 추천함으로써 학생들이 자신의 진로를 올바르게 설계할 수 있도록 지원하고 있습니다.</p>
                    </div>                   
                    <br />
                    <div className='search'>
                        <input type="text" placeholder='학번' />
                        <button  className='search-b' type='submit'>
                            <img src="images_sje/search_icon_s.svg" alt="검색" />
                        </button>
                    </div>
                    <div className='student'>
                        <p>학생이름</p>
                        <p>학번</p>
                        <p>지역</p>
                        <p>내신등급</p>
                    </div>
                    <br />
                    <hr />
                    <br />
                    <div className='school'>
                        <p>학교이름</p>
                        <p>지역</p>
                        <p>등급</p>
                    </div>
                    <br />
                    <button onClick={toggleDropdown} className="toggle-button">
                    {isOpen ? '진학 학교 추천 프로그램 자료' : '진학 학교 추천 프로그램 자료'}
                        <img
                            src={isOpen ? "images_sje/down.svg" : "images_sje/up.svg"}
                            alt={isOpen ? "닫기" : "열기"}
                            className="toggle-icon"
                        />
                    </button>
                    <div className='imgdata'>
                        <div className='data'>
                            <div className={`dropdown-container ${isOpen ? 'open' : ''}`}>
                                <img className='img2' src="images_sje/school_local_count.png" alt="자료2" />
                                <img className='img3' src="images_sje/school_type.png" alt="자료3" />
                                <img className='img1' src="images_sje/gogohi.jpg" alt="자료1" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default SchoolSearch_sje;
