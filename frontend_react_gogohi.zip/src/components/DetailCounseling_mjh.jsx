import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import axios from 'axios';
import '../css/detailCounseling_mjh.css';


function DetailCounseling_mjh() {
    const [counseling, setCounseling] = useState({});

    const { counselingNumber } = useParams();

    const history = useHistory();

    useEffect(() => {
        const fetchCounseling = async () => {
            try {
                const response = await axios.get(`http://localhost:9008/api/counseling_mjh/${counselingNumber}`);
                setCounseling(response.data);
            } catch (error) {
                console.log(error);
            }
        }
        fetchCounseling();
    }, [counselingNumber]);

    const handleDeleteCounsel = async (counselingNumber) => {
        if (window.confirm("게시글을 삭제하시겠습니까?")) {
            try {
                await axios.delete(`http://localhost:9008/api/counseling_mjh/${counselingNumber}`);
                alert('게시글이 삭제되었습니다.');
                console.log();
                // 삭제 성공 후, 게시글 목록에서 해당 게시글을 제거합니다.                
                history.push('/listCounsel');
                setCounseling(counseling.filter(counseling => counseling.counselingNumber !== counselingNumber));

            } catch (error) {
                console.error("게시글 삭제 실패", error);
            }
        }
    };

    const goToCounselingList = () => {
        history.push('/listCounsel');
    };
    const goToCounselingEdit = () => {
        history.push(`/editcounsel/${counselingNumber}`);
    };

    return (
        <div className='counselDetailWrapper_mjh'>
            <div className='counselDetailHead_mjh'>
                <h1>학생 상담</h1>
                <h2 style={{ textAlign: 'center' }}>{counseling.counselingTitle} </h2>
                <div className='counselDetailButton1_mjh'>
                <button onClick={goToCounselingList}>글 목록으로</button>
                </div>
            </div>
            <div className='counselDetailContents_mjh'>
                <p>{counseling.avgRank}{counseling.counselingContents}</p>
            </div>
            {/* {notice.imagePath && <img src={notice.imagePath} alt='Notice' style={{maxWidth:'100px', maxHeight:'100px'}} />} */}
            <div className=''>
                <div className='counselDetailWriter_mjh'>
                    <p>작성자 : {counseling.counselingWriter}</p>
                </div>
                <div className='counselDetailDate_mjh'>
                    <p>작성일 : {counseling.counselingDate}</p>
                </div>
            </div>
            <div className='counselDetailButton2_mjh'>
                <button onClick={goToCounselingEdit}>수정</button>
                <button onClick={() => handleDeleteCounsel(counseling.counselingNumber)}>글 삭제</button>
            </div>
        </div>
    );
}

export default DetailCounseling_mjh;