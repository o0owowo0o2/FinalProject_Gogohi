import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useHistory } from 'react-router-dom';

function Student_Edit_jje() {
    const [student, setStudent] = useState({ boardTitle: '', boardContents: '', boardWriter: '' });
    const { boardNumber } = useParams();
    const history = useHistory();

    useEffect(() => {
        // 게시글 정보를 가져오는 함수
        const fetchStudent = async () => {
            try {
                const response = await axios.get(`http://localhost:9008/api/students/${boardNumber}`);
                setStudent(response.data);
            } catch (error) {
                console.log(error);
            }
        };
        fetchStudent();
    }, [boardNumber]);

    // input 변경 핸들러
    const handleChange = (e) => {
        const { name, value } = e.target; // boardNumber 대신 name을 사용
        setStudent(prev => ({ ...prev, [name]: value })); // name에 해당하는 필드를 업데이트
    };

    // 게시글 수정 처리 핸들러
    const handleUpdate = async () => {
        try {
            const { boardWriter, ...updateData } = student;
            // boardWriter 대신 boardNumber로 PUT 요청을 보냅니다.
            await axios.put(`http://localhost:9008/api/students/${boardNumber}`, updateData);
            alert('게시글이 수정되었습니다.');
            history.push('/student_list');
        } catch (error) {
            console.error("게시글 수정 실패", error);
        }
    };

    const handleCancel = () => {
        history.goBack();
    };

    const goToCommunityList = () => {
        history.push('/student_list');
    };

    return (
        <div>
            <h2>게시글 수정</h2>
            <form>
                <div>
                    <label>제목</label>
                    <input type="text" name="boardTitle" value={student.boardTitle || ''} onChange={handleChange} />
                </div><br /><br />
                <div>
                    <label>내용</label>
                    <textarea name="boardContents" value={student.boardContents || ''} onChange={handleChange} />
                </div><br /><br />
                <div>
                    <label>작성자 : {student.boardWriter}</label> <br /><br />
                </div>
                <button type="button" onClick={handleUpdate}>수정 처리</button>
                <button type="button" onClick={handleCancel}>수정 취소</button><br /><br />
                <div>            
                    <button onClick={goToCommunityList}>글목록으로 이동</button> 
                </div>
            </form>
        </div>
    );
}

export default Student_Edit_jje;
