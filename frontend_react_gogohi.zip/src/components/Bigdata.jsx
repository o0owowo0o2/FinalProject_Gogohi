// React 및 필요한 라이브러리들 임포트
import React, { useState } from 'react'; // React와 useState 훅을 사용하여 컴포넌트의 상태 관리
import axios from 'axios'; // axios를 사용하여 HTTP 요청을 처리
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'; // React Router를 사용하여 라우팅 처리
import '../css_csb/Bigdata_csb.css'; // CSS 파일 불러오기

// 메인 App 컴포넌트 정의
const App = () => {
  const [loading, setLoading] = useState(false); // 로딩 상태 관리

  // 크롤링 요청을 처리하는 함수
  const handleOpenapiCrawling = async () => {
    setLoading(true); // 데이터 처리 시작 시 로딩 상태 true로 설정
    try {
      // axios를 사용하여 서버에 POST 요청을 보내고 크롤링 처리
      const response = await axios.post("http://localhost:5000/openapi"); // 로컬 서버에 크롤링 요청

      // 서버에서 반환된 응답 데이터를 콘솔에 출력 (디버깅용)
      console.log(response.data); // 서버에서 반환된 응답 데이터를 콘솔에 출력

      // 크롤링이 성공적으로 완료되었음을 알리는 alert 메시지
      alert("빅데이터 크롤링이 완료되었습니다!"); // 성공했을 때 알림창 표시

    } catch (error) {
      // 오류 발생 시 콘솔에 오류 메시지 출력
      console.error("Error:", error.response ? error.response.data : error.message); // 오류 로그 출력

      // 오류 발생 시 사용자에게 알림
      alert("오류가 발생했습니다!"); // 오류 발생 시 알림창 띄움
    } finally {
      setLoading(false); // 처리 완료 후 로딩 상태 false로 설정
    }
  };

  return (
    <Router>
      <Switch>
        <Route path="/">
          <div className="container_csb3"> {/* container 클래스를 container_csb3로 변경 */}
            <h1>빅데이터 학교 정보 크롤링_OpenAPI</h1> {/* 페이지 제목 */}
            
            {/* 크롤링 시작 버튼 */}
            <button className="csb" onClick={handleOpenapiCrawling}>
              공공 빅데이터 학교 정보 크롤링 시작
            </button> {/* 버튼을 누르면 handleOpenapiCrawling 함수 실행 */}
            {loading && <p>데이터 크롤링중...</p>} {/* 로딩 상태에 따라 메시지 표시 */}
          </div>
        </Route>
      </Switch>
    </Router>
  );
};

// App 컴포넌트를 기본으로 내보내기
export default App;
