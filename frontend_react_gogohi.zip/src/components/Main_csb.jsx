import React from 'react';
import { Link } from 'react-router-dom';
import '../css_csb/Main_csb.css'; // CSS 파일 import

function Main_csb() {
    const memberData_csb1 = JSON.parse(localStorage.getItem("loggedInMember"));

    const handleLogout_csb1 = () => {
        localStorage.removeItem("loggedInMember");
        alert("로그아웃 되었습니다");
        window.location.href = '/'; // 새로고침하면서 '/' 경로로 이동
    };

    return (
        <div className="main_csb1">
            <h1 className="main-header_csb1">메인 페이지</h1>
            <div className="member-info_csb1">
                {memberData_csb1 ? (
                    <p>아이디: {memberData_csb1.memberId}</p>
                ) : (
                    <p>로그인되지 않았습니다.</p>
                )}
            </div>
            <div className="links_csb1">
                <Link to='/membermain' className="link_csb1">Login 및 회원가입 하러가기</Link>
                <Link to='/loginMain' className="link_csb1">내 정보</Link>
            </div>
            <button onClick={handleLogout_csb1} className="logout-button_csb1">로그아웃</button>
        </div>
    );
}

export default Main_csb;
