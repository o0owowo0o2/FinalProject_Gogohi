import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import '../css/index_sje.css';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';

function Index_sje() {
  const [domain, setDomain] = useState('');
  const [isCustomDomain, setIsCustomDomain] = useState(false);
  const [amount, setAmount] = useState(''); // 후원 금액 상태 추가
  const [amountError, setAmountError] = useState(''); // 금액 오류 메시지 상태 추가

  const handleDomainChange = (event) => {
    const selectedDomain = event.target.value;
    if (selectedDomain === "custom") {
      setIsCustomDomain(true);
      setDomain('');
    } else {
      setIsCustomDomain(false);
      setDomain(selectedDomain);
    }
  };

  const [formData, setFormData] = useState({
    name: '졸업생 동문 후원 결제',
    amount: '',
    buyer_email: '',
    buyer_name: '',
    buyer_tel: '',
    buyer_addr: '',
    buyer_postcode: ''
  });

  const history = useHistory();

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === 'amount') {
      setAmount(value); // 후원 금액 상태 업데이트
      if (value < 100) {
        setAmountError('* 10,000원 이상부터 후원이 가능합니다.');
      } else {
        setAmountError(''); // 오류 메시지 초기화
      }
    }

    if (name === 'email_local') {
      setFormData({ ...formData, buyer_email: `${value}@${domain}` });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (amount < 100) {
      setAmountError('* 10,000원 이상부터 후원이 가능합니다.');
      return; // 금액이 10,000원 이하일 경우 폼 제출 중단
    }
    const query = new URLSearchParams(formData).toString();
    history.push(`/payment_sje?${query}`);
  };

  return (
    <div id='index_sje'>
      <div style={{width:'100', height:'56px'}} />
      <div className='wrapper'>
        <h1 className='header'>졸업생 동문 후원결제</h1>
        <hr />
        <div className='content'>
          <form onSubmit={handleSubmit} className='form'>
            
            {/* 결제금액 */}
            <div className='index_input'>
                <span className='input_name'>결제금액</span>
                <input 
                  type="number" 
                  name="amount" 
                  placeholder="결제금액" 
                  onChange={handleChange} 
                />
                <p 
                  className='amountError' 
                  style={{ visibility: amountError ? 'visible' : 'hidden'}}
                >
                  {amountError}
                </p>
            </div>

            {/* 이메일 */}
            <div className='email'>
              <span className='input_name'>이메일</span>
              <div className='index_input email-container'>
                <input 
                  type="text" 
                  name="email_local" 
                  placeholder="이메일" 
                  onChange={handleChange}
                />
                <span className='at'>@</span>
                {isCustomDomain ? (
                  <input 
                    type="text" 
                    value={domain} 
                    onChange={(e) => setDomain(e.target.value)} 
                    placeholder="도메인 입력"
                  />
                ) : (
                  <select value={domain} onChange={handleDomainChange}>
                    <option value="">도메인 선택</option>
                    <option value="naver.com">naver.com</option>
                    <option value="gmail.com">gmail.com</option>
                    <option value="hanmail.net">hanmail.net</option>
                    <option value="nate.com">nate.com</option>
                    <option value="kakao.com">kakao.com</option>
                    <option value="custom">직접 입력</option>
                  </select>
                )}
              </div>
            </div>

            {/* 이름 */}
            <div className='index_input'>
                <span className='input_name'>이름</span>
                <input 
                  type="text" 
                  name="buyer_name" 
                  placeholder="이름" 
                  onChange={handleChange} 
                />
            </div>

            {/* 전화번호 */}
            <div className='index_input'>
                <span className='input_name'>전화번호</span>
                <input 
                  type="tel" 
                  name="buyer_tel" 
                  placeholder="전화번호" 
                  onChange={handleChange} 
                />
            </div>

            {/* 주소 */}
            <div className='index_input'>
                <span className='input_name'>주소</span>
                <input 
                  type="text" 
                  name="buyer_addr" 
                  placeholder="주소" 
                  onChange={handleChange} 
                />
            </div>
          
            {/* 우편번호 */}
            <div className='index_input'>
                <span className='input_name'>우편번호</span>
                <input 
                  type="text" 
                  name="buyer_postcode" 
                  placeholder="우편번호" 
                  onChange={handleChange} 
                />
            </div>
            <div className='index_input2'>
                <button className='index_b' type="submit">확인</button>
                <Link to="/main" className='index-link'>돌아가기</Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Index_sje;
