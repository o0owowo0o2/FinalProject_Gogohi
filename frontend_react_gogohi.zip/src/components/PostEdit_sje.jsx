import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useHistory } from 'react-router-dom';
import '../css/postEdit_sje.css';

function PostEdit_sje() {
    // 작성자 정보를 포함하여 상태 초기화
    const [post_sje, setPost] = useState({ boardTitle: '', boardContents: '', boardWriter: '' }); // 초기 상태 설정
    const { boardNumber } = useParams(); // URL로부터 boardNumber 추출
    const history = useHistory(); // 페이지 이동을 위한 history 객체

    useEffect(() => {
        // 게시글 정보를 가져오는 함수
        const fetchPost = async () => {
            try {
                const response = await axios.get(`http://localhost:9008/api/posts_sje/${boardNumber}`);
                setPost(response.data); // 상태 업데이트
            } catch (error) {
                console.log(error); // 에러 로깅
            }
        };
        fetchPost(); // 함수 실행
    }, [boardNumber]); // 의존성 배열 설정

    // input 변경 핸들러
    const handleChange = (e) => {
        const { name, value } = e.target;
        setPost(prev => ({ ...prev, [name]: value }));
    };

   
    // 게시글 수정 처리 핸들러
    const handleUpdate = async () => {
        try {
            // 작성자 정보는 제외하고 수정 요청을 보냅니다.
            const { boardWriter, ...updateData } = post_sje;
            await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/posts_sje/${boardNumber}`, updateData);
            alert('게시글이 수정되었습니다.');
            history.push('/postList_sje'); // 수정 후 메인 페이지로 이동
        } catch (error) {
            console.error("게시글 수정 실패", error);
        }
    };

    // 수정 취소 핸들러
    const handleCancel = () => {
        history.goBack(); // 이전 페이지로 이동
    };

        return (
            <div id='postEdit_sje'>
                <div style={{width:'100', height:'56px'}} />
                <div className='wrapper'>
                    <form>
                        <div className='header'>
                            <input type="text" name="boardTitle" value={post_sje.boardTitle || ''} onChange={handleChange} />
                        </div>
                        <hr />
                        <div className='content'>
                            <div className='contents'>
                                <textarea name="boardContents" value={post_sje.boardContents || ''} onChange={handleChange} />
                            </div>
                            <div className='writer-info'>
                                <input type="text" name="boardWriter" placeholder='작성자' value={post_sje.boardWriter} readOnly/>
                            </div>
                            <div className='buttons'>
                                <button className='s' type="button" onClick={handleUpdate}>수정</button>
                                <button className='r' type="button" onClick={handleCancel}>취소</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        );
        
}

export default PostEdit_sje;