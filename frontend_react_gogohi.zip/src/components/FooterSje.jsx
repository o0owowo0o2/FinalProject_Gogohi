import React from 'react';
import "../css/footer_sje.css";
import { Link } from 'react-router-dom';

function FooterSje() {
    return (
        <div id='footer_sje'>
            <div className='wrapper'>
                <div className='menu'>
                    <ul>
                        <Link to="/01"><li>공지사항</li></Link>
                        <Link to="/02"><li>이용약관</li></Link>
                        <Link to="/03"><li>이용안내</li></Link>
                        <Link to="/04"><li>개인정보취급방식</li></Link>
                        <Link to="/05"><li>상담센터</li></Link>
                    </ul>
                </div>
                <div className='content'>
                    <ul>
                        <li>경기 성남시 분당구 성남대로 36 구미동 185-2 우편번호 13637</li>
                        <li>교무실(02-7567-2123) 행정실(02-2123-7567)</li>
                        <li>이메일(gogowebmaster@gogo.co.kr)</li>
                    </ul>
                    <p>Copyright © Hi Middle School, All Right Reserved.</p>
                </div>
            </div>
        </div>
    );
}

export default FooterSje;