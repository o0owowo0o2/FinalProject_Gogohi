import React, { useCallback, useEffect, useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';
import { Link } from 'react-router-dom';
import Pagination from './Pagination_mjh';
import '../css/listCounseling_mjh.css';

function ListCounseling_mjh() {
    const history = useHistory();

    // 게시물 목록, 현재 페이지, 총 페이지 수, 로드 상태, 검색어를 위한 상태 변수들을 설정합니다.
    const [counselings, setCounselings] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);
    const counselingsPerPage = 5;
    const [isLoaded, setIsLoaded] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');

    const fetchCounselings = useCallback(async () => {
        setIsLoaded(false);
        try {
            const response = await axios.get(`http://localhost:9008/api/counseling_mjh/list`, {
                params: {
                    page: currentPage - 1,
                    size: counselingsPerPage,
                    search: searchTerm
                },
            });
            console.log(response.data);
            setCounselings(response.data.content);
            setTotalPages(response.data.totalPages);
            setIsLoaded(true);
        } catch (error) {
            console.error("게시글 목록 조회 에러", error);
            setIsLoaded(true); // 에러가 발생해도 로드 상태를 true로 변경합니다.
        }
    }, [currentPage, counselingsPerPage, searchTerm]);

    useEffect(() => {
        fetchCounselings();
    }, [fetchCounselings]);

    // 페이지 번호를 변경하는 함수
    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    const createCounsel = () => {
        history.push("/createCounsel");
    }

    return (
        <div className='counselListWrapper_mjh'>
            <h1 className='counselListHead_mjh'>진학 상담 게시판</h1>
            <div className='imageSpanWrapper_mjh'>
                <div className='schoolImage_mjh'>
                    <img src="/images/forCounseling.jpg" alt="school_image" />
                </div>
                <span className='span_mjh'>본 게시판은 학생 여러분과 학부모님들이 진학에 관한 궁금증을 해결하고, <br />
                    보다 나은 선택을 할 수 있도록 도움을 드리기 위해 마련되었습니다. <br />
                    진로 선택, 대학 입시, 학과 정보 등 진학과 관련된 다양한 주제에 대해 <br />질문을 남겨주시면, 전문 상담 선생님들이 성심껏 답변을 드립니다.
                    <br /> <br />
                    <li>운영 시간: 평일 9:00 - 17:00</li>
                    <li> 상담 주제: 진학 정보, 입시 준비, 학과 선택, 진로 상담 등</li>
                    <li>문의 방법: 질문 게시글 작성 후 답변 기다리기</li>
                </span>
            </div>
            <div>
            </div>
            {isLoaded && (
                <>

                    {/* HTML 구조를 올바르게 수정 */}
                    <table className='counselList_mjh'>
                        <thead className='counselListTh_mjh'>
                            <td className='searchInput_mjh'>
                                <input type="text" placeholder='검색어를 입력하세요.' value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                                <button onClick={() => setCurrentPage(1)}> 검색</button> <br />
                            </td>
                            <tr className='trTh_mjh'>
                                <th className='thNumber_mjh'>번 호</th>
                                <th className='thTitle_mjh'>제 목</th>
                                <th className='thWriter_mjh'> 작 성 자</th>
                                <th className='thDate_mjh'>작 성 일</th>
                            </tr>
                        </thead>
                        <tbody className='counselTbody_mjh'>
                            {counselings.map(counseling => (
                                console.log("counseling객체" + counseling),

                                <tr className='listCounseling_mjh' key={counseling.counselingNumber}>
                                    <td className='listCounselNumber_mjh'>{counseling.counselingNumber}</td>
                                    <td className='listCounselTitle_mjh'>
                                        {/* Link를 <td> 내부에 배치 */}
                                        <Link className='listCounselLink_mjh' to={`/detailCounsel/${counseling.counselingNumber}`}>
                                            <td>{counseling.counselingTitle}</td>
                                        </Link>
                                    </td>
                                    <td className='listCounselWriter_mjh'>{counseling.counselingWriter}</td>
                                    <td className='listCounselDate_mjh'>{counseling.counselingDate}</td>
                                </tr>
                            ))}

                            <td className='btn_createCounsel_mjh'>
                                <button onClick={createCounsel}>글쓰기</button>
                            </td>
                             {/* 로드 완료 시 내용을 표시 */}
                    <td className='pagination_mjh'>
                        {/* 페이징 컴포넌트 */}
                        <Pagination currentPage={currentPage} totalPages={totalPages} paginate={paginate} />
                    </td>
                        </tbody>
                    </table>

                    <div >

                    </div>

                   
                </>
            )}
        </div>
    );
}

export default ListCounseling_mjh;
