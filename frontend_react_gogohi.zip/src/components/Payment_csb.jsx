import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import '../css_csb/payment_csb.css';

function Payment_csb() {
  const [paymentData, setPaymentData] = useState({});
  const location = useLocation();

  useEffect(() => {
    const IMP = window.IMP;
    IMP.init("imp46746806");

    const query = new URLSearchParams(location.search);
    const formattedAmount = query.get('amount') ? Intl.NumberFormat('ko-KR').format(query.get('amount')) + "원" : "0원";
    setPaymentData({
      name: query.get('name'),
      amount: formattedAmount,
      buyer_email: query.get('buyer_email'),
      buyer_name: query.get('buyer_name'),
      buyer_tel: query.get('buyer_tel'),
      buyer_addr: query.get('buyer_addr'),
      buyer_postcode: query.get('buyer_postcode')
    });
  }, [location.search]);

  const handlePayment = () => {
    const IMP = window.IMP;
    IMP.request_pay({
      pg: "html5_inicis",
      pay_method: "card",
      merchant_uid: `merchant_${new Date().getTime()}`,
      ...paymentData,
      amount: paymentData.amount.replace(/원|,/g, ''),
      m_redirect_url: "/paymentSuccess"
    }, function (rsp) {
      if (rsp.success) {
        axios.post('http://localhost:9008/api/payment/process', {
          imp_uid: rsp.imp_uid,
          merchant_uid: rsp.merchant_uid,
          pay_amount: rsp.paid_amount,
          apply_num: rsp.apply_num,
          per_time: new Date()
        }, {
          headers: { 'Content-Type': 'application/json' }
        }).then(response => {
          window.location.href = "/paymentSuccess";
        }).catch(error => {
          console.error('결제 정보 전송 에러', error);
        });
      } else {
        alert(`결제 실패: ${rsp.error_msg}`);
      }
    });
  };

  return (
    <div className="payment-container_csb">
      <img src="/images/back.jpg" alt="Classroom" />
      <div className="payment-form_csb">
        <h2>후원 정보 확인</h2>
        <ul>
          <li>후원기업명: {paymentData.name}</li>
          <li>후원 금액: {paymentData.amount}</li>
          <li>후원자 이메일: {paymentData.buyer_email}</li>
          <li>후원자 이름: {paymentData.buyer_name}</li>
          <li>후원자 연락처: {paymentData.buyer_tel}</li>
          <li>후원자 우편번호: {paymentData.buyer_postcode}</li>
          <li>후원자 주소: {paymentData.buyer_addr}</li>
        </ul>
        <button onClick={handlePayment}>후원하기</button>
      </div>
    </div>
  );
}

export default Payment_csb;
