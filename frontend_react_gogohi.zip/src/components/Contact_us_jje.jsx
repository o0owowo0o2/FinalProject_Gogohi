import React, { useState } from 'react';
import axios from 'axios'; // axios 임포트
import { useHistory } from 'react-router-dom'; // useHistory 임포트
import '../css/contact_us.css';

function Contact_us_jje() {
    const [contect, setFormData] = useState({
        boardWriter: '',
        boardEmail: '',
        boardContents: '',
    });

    const history = useHistory(); // useHistory 훅 사용

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...contect,
            [name]: value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:9008/api/contects', contect);
            alert("문의사항이 등록되었습니다");
            console.log(response.data);
            history.push('/main');
        } catch (error) {
            console.error("문의사항 작성이 실패하였습니다.", error);
            alert("문의사항 작성 실패");
        }
        setFormData({ boardWriter: '', boardEmail: '', boardContents: '' }); // Reset form
    };

    return (
        <div id='jje'>
        <div className="contact-container">
            <div className="contact-header">
                <h2>문의하기</h2>
                <p>문의사항이나 불편하신 점 있으면 아낌없이 적어주세요!</p>
            </div>
            <form onSubmit={handleSubmit} className="contact-form">
                <div className="form-group">
                    <label htmlFor="boardWriter">이름</label>
                    <input
                        type="text"
                        id="boardWriter"
                        name="boardWriter"
                        value={contect.boardWriter}
                        onChange={handleChange}
                        placeholder="이름을 적어주세요"
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="boardEmail">이메일</label>
                    <input
                        type="email"
                        id="boardEmail"
                        name="boardEmail"
                        value={contect.boardEmail}
                        onChange={handleChange}
                        placeholder="이메일을 적어주세요"
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="boardContents">문의사항</label>
                    <textarea
                        id="boardContents"
                        name="boardContents"
                        value={contect.boardContents}
                        onChange={handleChange}
                        placeholder="문의사항을 적어주세요"
                        required
                    ></textarea>
                </div>
                <button type="submit" className="submit-btn">전송</button>
            </form>
        </div>
        </div>
    );
}

export default Contact_us_jje;
