import React from 'react';
import { Link } from 'react-router-dom';

function Location_sje() {
    return (
        <div>
            <br />
            <br />
            <br />
            <Link to="/main">main</Link>
        </div>
    );
}

export default Location_sje;