import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import axios from 'axios';
import '../css/editCounseling_mjh.css';

function EditCounseling_mjh() {
    const[counseling, setCounseling] = useState({
        counselingTitle:'',
        counselingContents:'',
        counselingWriter:'',
        counselingEmail:'',
        counselingDate:''
    });
    const{counselingNumber} = useParams();
    
    const history = useHistory();
    
    useEffect(() => {
        const fetchCounseling = async() => {
            try {
                const response = await axios.get(`http://localhost:9008/api/counseling_mjh/${counselingNumber}`);
                setCounseling({
                    counselingNumber: response.data.counselingNumber,
                    counselingTitle: response.data.counselingTitle,
                    counselingContents: response.data.counselingContents,
                    counselingWriter: response.data.counselingWriter,
                    counselingEmail: response.data.counselingEmail,
                    counselingDate: response.data.counselingDate
            });
            } catch (error) {
                console.log(error);
                alert('에러가 발생했습니다!');
            }
        }
        fetchCounseling();
    },[counselingNumber]);

    const handleChange = (e) => {
        const{name,value} = e.target;
        setCounseling(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleUpdate = async() => {
        try {
            const{counselingWriter, ...updateData} = counseling;
            await axios.put(`http://localhost:9008/api/counseling_mjh/${counselingNumber}`,updateData);
            alert('게시글이 수정되었습니다!'); 
            history.push("/listCounsel");
        } catch (error) {
            console.error("게시글 수정 실패", error);
        } 
    }
    const handleCancel = () => {
        history.goBack(); // 브라우저의 이전 페이지로 이동합니다.
    };
    const goToMain = () => {
        history.push("/main"); 
    };

    return (
        <div className='editCounselWrapper_mjh'>
            <h2 className='h1_mjh'>글 수정</h2>
            <form>
                <div className='editCounselTitle_mjh'>
                <div className='editCounselbtn2_mjh'>
                    <button type='button' onClick={goToMain}>메인페이지</button>   
                </div>
                    <div className='editCounselSpan_mjh'><span>제목</span></div>
                        <input type="text" name='counselingTitle' value={counseling.counselingTitle || ''} onChange={handleChange}/> <br />
            </div>
            <div className='editCounselContent_mjh'>
                <span className='editCounselSpan_mjh'>내용</span>  
                <textarea name="counselingContents" value={counseling.counselingContents || ''} onChange={handleChange} /> <br />
            </div>
                <div className='editCounselEtc_mjh'>
                    <div className='editCounselSpan_mjh'><span>작성자 : {counseling.counselingWriter}</span></div><br />
                    <div className='editCounselSpan_mjh'><span>Email : {counseling.counselingEmail}</span></div><br />
                    <div className='editCounselSpan_mjh'><span>작성일 : {counseling.counselingDate}</span></div>
                </div>
                <br />
                <div className='editCounselbtn1_mjh'>
                    <button type='button' onClick={handleUpdate}>수정</button>
                    <button type='button' onClick={handleCancel}>취소</button>   
                </div>
                <br />
                

            </form>
        </div>
    );
}
export default EditCounseling_mjh;