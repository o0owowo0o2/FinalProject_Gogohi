import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import '../css_csb/index_csb.css';

function Index_csb() {
  const [formData, setFormData] = useState({
    name: '',
    amount: '',
    buyer_email: '',
    buyer_name: '',
    buyer_tel: '',
    buyer_addr: '',
    buyer_postcode: ''
  });

  const history = useHistory();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const query = new URLSearchParams(formData).toString();
    history.push(`/payment?${query}`);
  };

  return (
    <div id='csb'>
    <div className="index-container_csb">
      <div className="index-background_csb">
        <img src="/images/back.jpg" alt="Classroom" />
      </div>
      <div className="index-form_csb">
        <h1>감사합니다!</h1>
        <form onSubmit={handleSubmit}>
          <input type="text" name="name" placeholder="후원기업명" onChange={handleChange} />
          <input type="number" name="amount" placeholder="결제금액" onChange={handleChange} />
          <input type="email" name="buyer_email" placeholder="후원자 이메일" onChange={handleChange} />
          <input type="text" name="buyer_name" placeholder="후원자 이름" onChange={handleChange} />
          <input type="tel" name="buyer_tel" placeholder="후원자 연락처" onChange={handleChange} />
          <input type="text" name="buyer_postcode" placeholder="후원자 주소우편번호" onChange={handleChange} />
          <input type="text" name="buyer_addr" placeholder="후원자 주소" onChange={handleChange} />
          <button type="submit">후원하기</button>
        </form>
      </div>
    </div>
    </div>
  );
}

export default Index_csb;
