import React from 'react';
import "../css/main_sje.css";
import { Link } from 'react-router-dom';

function Main_sje() {
    return (
        <div id='main-sje'>
            <div className='wrapper'>
                <div className='main-banner'>
                    <img className='m-full' src="images/main_full.jpg" alt="메인배너1" />
                    <img className='m-t' src="images/main_t.jpg" alt="메인배너2" />
                    <img className='m-m' src="images/main_m.jpg" alt="메인배너3" />
                </div>
                <div className='content'>
                    <div className='content-1'>
                        <div className='con1-1'>
                            <p className='header'>공지사항</p>
                            <ul>
                                <li>2025년 입학설명회</li>
                                <li>2024년 학사일정</li>
                                <li>10월 1일 '국군의 날'의 임시공휴일로 변경됨에 따른 기말고사 연기 안내문</li>
                                <li>학교 외부인 출입 통제 안내문</li>
                            </ul>
                        </div>
                        <div className='con1-2'>
                            <p className='header'>가정통신문</p>
                            <ul>
                                <li>1</li>
                                <li>1</li>
                                <li>1</li>
                                <li>1</li>
                            </ul>
                        </div>
                    </div>
                    <div className='content-2'>
                        <div className='content-2-link'>
                            <Link to="/location">자세히보기 ▶</Link>
                        </div>
                        <img src="images/subbanner_sje.jpg" alt="서브배너" />
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Main_sje;