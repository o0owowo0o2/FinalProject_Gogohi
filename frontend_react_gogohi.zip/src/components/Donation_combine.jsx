import React from 'react';
import { useHistory } from 'react-router-dom';
import '../css_csb/donation_combine.css';

function DonationCombine() {
  const history = useHistory();

  const handleNavigation = (path) => {
    history.push(path);
  };

  return (
    <div className="donation-container">
      <div className="donation-box school-love" onClick={() => handleNavigation('/infoPayment_mjh')}>
        <h2>학교사랑 후원결제</h2>
      </div>
      <div className="donation-box alumni" onClick={() => handleNavigation('/index_sje')}>
        <h2>졸업생 동문 후원결제</h2>
      </div>
      <div className="donation-box corporate" onClick={() => handleNavigation('/index_csb')}>
        <h2>기업 후원결제</h2>
      </div>
      <div className="thank-you">
        <h2>여러분의 소중한 후원 덕분에 한 걸음 더 나아갈 수 있었습니다.</h2>
        <br />
        더 나은 내일을 위해 끊임없이 발전하며, 언제나 신뢰와 감동을 드리는 모습으로 보답하겠습니다. 
        <br />
        진심 어린 응원과 관심에 깊이 감사드립니다. 
        <br />
        감사합니다.
      </div>
    </div>
  );
}

export default DonationCombine;
