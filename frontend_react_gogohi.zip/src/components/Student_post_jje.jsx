import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useHistory } from 'react-router-dom';
import Pagination from './Pagination';
import '../css/student_post.css'; // CSS 파일 임포트

function Student_post_jje() {
    const [students, setStudents] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);  
    const [studentsPerPage] = useState(10);  
    const [totalPages, setTotalPages] = useState(0);  
    const [isLoaded, setIsLoaded] = useState(false);  

    const history = useHistory();

    useEffect(() => {
        const fetchStudents = async () => {
            setIsLoaded(false);
            try {
                const response = await axios.get(`http://localhost:9008/api/students?page=${currentPage - 1}&size=${studentsPerPage}`);
                console.log("Response Data:", response.data);
                setStudents(response.data.content);
                setTotalPages(response.data.totalPages);
                setIsLoaded(true);
            } catch (error) {
                console.error("게시글 목록 조회 에러", error);
                setIsLoaded(true);
            }
        };
    
        fetchStudents();
    }, [currentPage, studentsPerPage]);
    

        
    

    const paginate = (pageNumber) => {
        if (pageNumber > 0 && pageNumber <= totalPages) {
            setCurrentPage(pageNumber);
        }
    };
     

    

    const goToCommunityRegister = () => {
        history.push('/student_create_post_');  
    };

    return (
        <div id='jje'>
        <div className="container">
            <h2>학생 자유 게시판</h2>
            <button onClick={goToCommunityRegister} className="register-btn">게시글 등록</button>
            {isLoaded && students.length > 0 ? (
                <>
<ul className="post-list">
    {students.map((student, index) => (
        <li key={student.boardNumber} className="post-item">
            {/* 게시글 번호를 총 게시글 수를 기준으로 계산 */}
            {/* <span className="post-number">{(currentPage - 1) * studentsPerPage + index + 1}.</span> */}
            <span className="post-number">{student.boardNumber}.</span>
            <Link to={`/students/${student.boardNumber}`}>
                <h3 className="post-title">{student.boardTitle}</h3>
            </Link>
            <p className="post-writer">작성자: {student.boardWriter}</p>
        </li>
    ))}
</ul>




                    <Pagination currentPage={currentPage} totalPages={totalPages} paginate={paginate} />
                </>
            ) : isLoaded ? (
                <p className="no-posts">게시글이 없습니다.</p>
            ) : (
                <p className="loading">로딩 중...</p>
            )}
        </div>
        </div>
    );
}

export default Student_post_jje;
