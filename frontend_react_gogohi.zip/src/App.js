import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css'; 
import Main_sje from './components/Main_sje';
import HeaderSje from './components/HeaderSje';
import Location_sje from './components/Location_sje';
import FooterSje from './components/FooterSje';

import './css/app_sje.css';

function App() {
  
  return (
    <Router>
      <div id='app'>
      <HeaderSje />
        <Switch>
          <Route path="/main" component={Main_sje} />
          <Route path="/location" component={Location_sje} />
        </Switch>
      <FooterSje />
      </div>
    </Router>
  );
}

export default App;
