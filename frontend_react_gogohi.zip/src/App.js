import { React, useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css'; 
import Main_sje from './components/Main_sje';
import HeaderSje from './components/HeaderSje';
import Location_sje from './components/Location_sje';
import FooterSje from './components/FooterSje';
import Index_sje from './components/Index_sje';
import Payment_sje from './components/Payment_sje';
import PaymentSuccess_sje from './components/PaymentSuccess_sje';
import PostListSje from './components/PostListSje';
import CreatePost_sje from './components/CreatePost_sje';
import PostDetail_sje from './components/PostDetail_sje';
import PostEdit_sje from './components/PostEdit_sje';
import SchoolSearch_sje from './components/SchoolSearch_sje';

import Contact_us_jje from './components/Contact_us_jje';
import Landingpage_jje from './components/Landingpage_jje';
import Student_create_post_jje from './components/Student_create_post_jje';
import Student_Edit_jje from './components/Student_Edit_jje';
import Student_post_jje from './components/Student_post_jje';
import Student_post_detail_jje from './components/Student_post_detail_jje';

import FAQ_MDY from './components_mdy/FAQ_MDY';
import POPUP_MDY from './components_mdy/POPUP_MDY';
import ABOUT_MDY from './components_mdy/ABOUT_MDY';

import Payment_csb from './components/Payment_csb';
import Index_csb from './components/Index_csb';
import Donation_combine from './components/Donation_combine';
import PaymentSuccess_csb from './components/PaymentSuccess_csb';
import Main_csb from './components/Main_csb';
import MemberEdit_csb7 from './components/MemberEdit_csb';
import MemberRegister_csb from './components/MemberRegister_csb';
import MemberMain_csb from './components/MemberMain_csb';
import LoginMain_csb from './components/LoginMain_csb';
import Ocr from './components/Ocr';
import Bigdata from './components/Bigdata';

import CreateCounseling_mjh from "./components/CreateCounseling_mjh";
import ListCounseling_mjh from "./components/ListCounseling_mjh";
import DetailCounseling_mjh from "./components/DetailCounseling_mjh";
import EditCounseling_mjh from "./components/EditCounseling_mjh";
import CreateNotice_mjh from "./components/CreateNotice_mjh";
import ListNotice_mjh from "./components/ListNotice_mjh";
import InfoPayment_mjh from "./components/InfoPayment_mjh";
import Payment_mjh from "./components/Payment_mjh";
import DetailNotice_mjh from "./components/DetailNotice_mjh";

import './css/app_sje.css';
import { useLocation } from 'react-router-dom';
import AddressPopup from './components/AddressPopup';
// import Landingpage_jje from './components/Landingpage_jje';

const  App = () => {

  const location = useLocation();
  const hideHeaderFooter = location.pathname === '/';

  const [showPopup, setShowPopup] = useState(true);

  useEffect(() => {
    const expiration = localStorage.getItem('popup-hide');
    if (expiration && new Date().getTime() < parseInt(expiration)) {
      setShowPopup(false);
    }
  }, []);

  const closePopup = () => {
    setShowPopup(false);
  };

  return (
      <div id='app'>
      {!hideHeaderFooter && <HeaderSje />}
        <Switch>
          {/* 문도연 */}
          <Route path="/about_mdy" component={ABOUT_MDY} />
          <Route path="/faq_mdy" component={FAQ_MDY} />
          {/* 서정은 */}
          <Route path="/main" component={Main_sje} exact={true}/>{/* 메인, 찾아오시는길 */}
          <Route path="/location" component={Location_sje} /> 
          <Route path="/index_sje" component={Index_sje} />{/* 결제 */}
          <Route path="/payment_sje" component={Payment_sje} />
          <Route path="/paymentSuccess_sje" component={PaymentSuccess_sje} />
          <Route path="/postList_sje" component={PostListSje} />{/* 교직원 게시판 */}
          <Route path="/postsSje" component={CreatePost_sje} />
          <Route path="/posts_sje/:boardNumber" component={PostDetail_sje} />
          <Route path="/edit_sje/:boardNumber" component={PostEdit_sje} />
          <Route path="/schoolSearch_sje" component={SchoolSearch_sje} />
          {/* 장정은 */}
          <Route path='/' component={Landingpage_jje} exact={true}></Route>
          <Route path='/student_edit/:boardNumber' component={Student_Edit_jje}></Route>
          <Route path='/student_list' component={Student_post_jje}></Route>
          <Route path='/student_create_post_' component={Student_create_post_jje}></Route>
          <Route path='/student/:boardNumber'component={Student_post_detail_jje}></Route>
          <Route path='/contact_us' component={Contact_us_jje}></Route>
          {/* 최승빈 */}
          <Route path="/index_csb" exact component={Index_csb} />
          <Route path="/payment" component={Payment_csb} />
          <Route path="/paymentSuccess" component={PaymentSuccess_csb} />
          <Route path="/donationcombine" component={Donation_combine} />
          <Route path="/"exact={true} component={Main_csb} />
          <Route path="/membermain" component={MemberMain_csb} />
          <Route path="/register" component={MemberRegister_csb} />
          <Route path="/loginMain" component={LoginMain_csb} />
          <Route path="/address-popup" component={AddressPopup} />
          <Route path="/edit_csb/:memberId" component={MemberEdit_csb7} />
          <Route path="/ocr" component={Ocr} />
          <Route path="/bigdata" component={Bigdata} />
           {/* 민지홍 */}
          <Route path="/createCounsel" component={CreateCounseling_mjh} />
          <Route path="/listCounsel" component={ListCounseling_mjh} />
          <Route path="/detailCounsel/:counselingNumber" component={DetailCounseling_mjh} />
          <Route path="/editCounsel/:counselingNumber" component={EditCounseling_mjh} />
          <Route path="/createNotice_mjh" component={CreateNotice_mjh} />
          <Route path="/listNotice_mjh" component={ListNotice_mjh} />
          <Route path="/detailNotice/:noticeNumber" component={DetailNotice_mjh} />
          <Route path="/infoPayment_mjh" component={InfoPayment_mjh} />
          <Route path="/payment_mjh" component={Payment_mjh} />
        </Switch>
        {!hideHeaderFooter && showPopup && <POPUP_MDY onClose={closePopup} />}
      {!hideHeaderFooter && <FooterSje />}
      </div>
  );
}

const AppWrapper = () => (
  <Router>
    <App />
  </Router>
);

export default AppWrapper;

