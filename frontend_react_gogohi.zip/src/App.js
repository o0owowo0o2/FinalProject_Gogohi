import { React, useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css'; 
import Main_sje from './components/Main_sje';
import HeaderSje from './components/HeaderSje';
import Location_sje from './components/Location_sje';
import FooterSje from './components/FooterSje';
import Index_sje from './components/Index_sje';
import Payment_sje from './components/Payment_sje';
import PaymentSuccess_sje from './components/PaymentSuccess_sje';
import PostListSje from './components/PostListSje';
import CreatePost_sje from './components/CreatePost_sje';
import PostDetail_sje from './components/PostDetail_sje';
import PostEdit_sje from './components/PostEdit_sje';

import FAQ_MDY from './components_mdy/FAQ_MDY';
import POPUP_MDY from './components_mdy/POPUP_MDY';
import ABOUT_MDY from './components_mdy/ABOUT_MDY';

import './css/app_sje.css';

function App() {

  const [showPopup, setShowPopup] = useState(true);

  useEffect(() => {
    const expiration = localStorage.getItem('popup-hide');
    if (expiration && new Date().getTime() < parseInt(expiration)) {
      setShowPopup(false);
    }
  }, []);

  const closePopup = () => {
    setShowPopup(false);
  };
  
  return (
    <Router>
      <div id='app'>
      <HeaderSje />
        <Switch>
          {/* 문도연 */}
          <Route exact path="/" component={Main_sje} />
          <Route path="/about_mdy" component={ABOUT_MDY} />
          <Route path="/faq_mdy" component={FAQ_MDY} />
          {/* 서정은 */}
          <Route path="/main" component={Main_sje} />{/* 메인, 찾아오시는길 */}
          <Route path="/location" component={Location_sje} /> 
          <Route path="/index_sje" component={Index_sje} />{/* 결제 */}
          <Route path="/payment_sje" component={Payment_sje} />
          <Route path="/paymentSuccess_sje" component={PaymentSuccess_sje} />
          <Route path="/postList_sje" component={PostListSje} />{/* 교직원 게시판 */}
          <Route path="/postsSje" component={CreatePost_sje} />
          <Route path="/posts_sje/:boardNumber" component={PostDetail_sje} />
          <Route path="/edit_sje/:boardNumber" component={PostEdit_sje} />
        </Switch>
        {showPopup && <POPUP_MDY onClose={closePopup} />}
      <FooterSje />
      </div>
    </Router>
  );
}

export default App;
