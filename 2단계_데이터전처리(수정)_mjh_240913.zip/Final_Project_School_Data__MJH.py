#!/usr/bin/env python
# coding: utf-8

# In[ ]:

import axis
import pandas as pd
pd.set_option('mode.chained_assignment', None)
import numpy as np
# glob : 경로와 이름을 지정하여 파일을 다루는 파일 처리 작업을 위한 모듈
import glob
# re : 메타 문자를 이용하여 특정 규칙을 작성하는 정규식을 사용하기 위한 모듈
import re
# reduce : 2차원 리스트를 1차원 리스트로 차원을 줄이기 위한 모듈
from functools import reduce
# word_tokenize : 자연어 처리 패키지(from nltk.tokenize) 중에서
# 단어 토큰화 작업을 위한 모듈
from nltk.tokenize import word_tokenize
# stopwords : 자연어 처리 패키지(from nltk.corplus) 중에서 불용어 정보를 제공하는 모듈
from nltk.corpus import stopwords
# WordNetLemmatizer : 자연어 처리 패키지(from nltk.stem) 중에서 단어 형태의 일반화를
# 위해 표제어 추출을 제공하는 모듈
from nltk.stem import WordNetLemmatizer
# Counter : 데이터 집합에서 개수를 자동으로 계산하기 위한 모듈
from collections import Counter
# matplotlib.pyplot : 히스토그램을 그리기 위한 matplotlib 패키지의 내부 모듈
# (matplotlib.pyplot as plt 의미는 plt 단어로 축약해서 별칭 사용합니다)
import matplotlib.pyplot as plt


# In[ ]:


school_df = pd.read_csv('C:\Python_Project\data/경기도_고등학교현황.csv', encoding = 'euc-kr', engine='python')


# In[ ]:


school_df.to_csv('C:\Python_Project\data/경기도_고등학교현황2.csv', index=False)


# In[ ]:


school_df.head()


# In[ ]:


school_df = school_df.drop(['WGS84위도'], axis =1)


# In[ ]:


school_df = school_df.drop(['WGS84경도'], axis =1)


# In[ ]:


school_df


# In[ ]:


def assign_rank(school_classification):
    if '과학' in school_classification:
        return 1
    elif '외' in school_classification:
        return 2
    elif '국제' in school_classification:
        return 1
    elif '특성화' in school_classification:
        return 4
    elif '예' in school_classification:
        return 5
    elif '비' in school_classification:
        return 3
    elif '자율' in school_classification:
        return 2
    elif '마이스터' in school_classification:
        return 1
    else:
        return 5


# In[ ]:


school_df['rank'] = school_df['고등학교구분명'].apply(assign_rank)


# In[ ]:


school_df.to_csv('C:\Python_Project\data/경기도_고등학교현황_0913.csv', encoding = 'euc-kr',index = False)


# In[ ]:


school_df = pd.read_csv('C:\Python_Project\data/학교정보0913.csv', encoding = 'euc-kr', engine = 'python')


# In[ ]:


school_df


# In[ ]:


school_df.columns[0]


# In[ ]:


school_df.rename(columns={'최소요구등급' : '진학가능내신등급'}, inplace= True)
school_df


# In[ ]:


school_df.drop([485], axis=0, inplace= True)


# In[ ]:


school_df


# In[ ]:


school_df = school_df.drop(school_df.columns[0], axis=1)


# In[ ]:


school_df


# In[ ]:


school_df.to_csv('C:\Python_Project\data/경기도_고등학교현황_전처리적용_mjh.csv', encoding = 'euc-kr',index = False)


# In[ ]:


school_df = pd.read_csv('C:\Python_Project\data/경기도_고등학교현황_전처리적용_mjh.csv', encoding = 'euc-kr')


# In[117]:


school_df


# In[185]:


school_df[school_df['소재지지번주소'].str.contains('성남시')] ## df[조건식]


# In[184]:


words_to_count = ['성남시']
count = school_df['소재지지번주소'].apply(lambda x: sum(word in x for word in words_to_count)).sum()

print(f"'{', '.join(words_to_count)}'의 고등학교는 총 {count}개 입니다.")


# In[ ]:


unique_cities = school_df['소재지지번주소'].dropna().drop_duplicates()

print("소재지지번주소:")
print(unique_cities)


# In[ ]:


addr = pd.DataFrame(school_df['소재지지번주소'].apply(lambda v : v.split()[:2]).tolist(), columns=('도', '시군구'))


# In[ ]:


addr


# In[ ]:


addr['시군구'].unique()


# In[ ]:


addr['도'].unique()


# In[ ]:


addr['count'] = 0
addr.head()


# In[ ]:


addr_cnt = pd.DataFrame(addr.groupby(['도','시군구'], as_index = False).count())


# In[ ]:


addr_cnt


# In[ ]:


from matplotlib import pyplot as plt


# In[188]:


# 데이터 준비
cities = ['안성시', '남양주시', '고양시', '가평군', '구리시', '하남시', '안양시', '부천시', '수원시',
          '여주시', '안산시', '평택시', '의정부시', '시흥시', '의왕시', '군포시', '광명시', '광주시',
          '성남시', '용인시', '김포시', '과천시', '포천시', '파주시', '화성시', '이천시', '양주시',
          '동두천시', '오산시', '양평군', '연천군']
counts = [9, 21, 38, 5, 7, 10, 21, 28, 44, 8, 24, 21, 16, 17, 5, 8, 11, 8, 36, 32, 14, 4, 7, 18, 29, 12, 8, 6, 8, 8, 2]

colors = ['green' if 30 > cities >= 20 else 'orange' if cities >= 30 else 'gray' for cities in counts]

# 그래프 생성
plt.figure(figsize=(10, 6))
plt.bar(cities, counts, color = colors)

# 그래프 제목 및 라벨 설정
plt.title('경기도 시군구별 학교 수')
plt.xlabel('시군구')
plt.ylabel('학교 수')

# x축 라벨 회전
plt.xticks(rotation=90)

# 그래프 출력
plt.tight_layout()
plt.savefig('school_local_count.png', dpi=300, bbox_inches='tight')
plt.show()


# In[98]:


unique_cities = school_df['소재지지번주소'].dropna().drop_duplicates()

print("소재지지번주소:")
print(unique_cities)


# In[99]:


school_df[school_df['고등학교구분명'].str.contains('과학고')] 


# In[100]:


school_df[school_df['고등학교구분명'].str.contains('외국어고')]


# In[116]:


school_df[school_df['고등학교구분명'].str.contains('마이스터고')]


# In[121]:


school_df[school_df['고등학교구분명'].str.contains('특성화고')]


# In[129]:


words_to_count = ['특성화고']
count = school_df['고등학교구분명'].apply(lambda x: sum(word in x for word in words_to_count)).sum()

print(f"'{', '.join(words_to_count)}'의 고등학교는 총 {count}개 입니다.")


# In[122]:


school_df[school_df['고등학교구분명'].str.contains('예고')]


# In[123]:


school_df[school_df['고등학교구분명'].str.contains('자율고')]


# In[137]:


school_df[school_df['고등학교구분명'].str.contains('비')]


# In[138]:


school_df[school_df['고등학교구분명'].str.contains('일반')]


# In[153]:


school_df[school_df['고등학교구분명'].str.contains('국제고')]


# In[110]:


schoolScience = pd.DataFrame(school_df['고등학교구분명'].apply(lambda v : v.split()[:1]).tolist(), columns=('과학고'))


# In[134]:


# 데이터 준비
cities = [ '안성시', '남양주시', '가평군', '구리시', '하남시', '안양시', '부천시','여주시', '안산시', '의왕시', '고양시', '과천시', '김포시', '동두천시', '성남시', '수원시', '평택시',
          '의정부시', '시흥시', '군포시', '광명시', '광주시','용인시', '포천시', '파주시', '화성시', '이천시', '양주시','오산시', '양평군', '연천군']
foreign = [ 0, 0, 0, 0, 0, 0, 0, 0, 0,1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# colors = ['green' if 30 > cities >= 20 else 'orange' if cities >= 30 else 'gray' for cities in counts]

# 그래프 생성
plt.figure(figsize=(8, 4))
plt.bar(cities, foreign)

# 그래프 제목 및 라벨 설정
plt.title('경기도 시군구별 외국어고 현황')
plt.xlabel('시군구')
plt.ylabel('외국어고 수')

# x축 라벨 회전
plt.xticks(rotation=90)

# 그래프 출력
plt.tight_layout()
plt.show()


# In[135]:


cities = ['일반고', '특성화고']
counts = [19, 2]

colors = ['green' if 30 > cities >= 20 else 'orange' if cities >= 30 else 'gray' for cities in counts]

# 그래프 생성
plt.figure(figsize=(4, 5))
plt.bar(cities, counts, color = colors)

# 그래프 제목 및 라벨 설정
plt.title('남양주시 학교 현황')
plt.xlabel('학교')
plt.ylabel('학교수')

# x축 라벨 회전
# plt.xticks(rotation=90)

# 그래프 출력
plt.tight_layout()
plt.show()


# In[189]:


schools = ['외국어고', '국제고','평준화 일반고', '비평준화 일반고', '특성화고','자율고', '예고', '마이스터고' ]
counts = [8, 3, 209, 188, 103, 3, 5, 3]

colors = ['brown' if 200 < cities  else 'orange' if cities >= 30 else 'green' for cities in counts]

# 그래프 생성
plt.figure(figsize=(10, 6))
bar = plt.bar(schools, counts, color = colors)

# 그래프에 숫자표시
for rect in bar:
    height = rect.get_height()
    plt.text(rect.get_x() + rect.get_width()/2.0, height, '%d개' % height, ha='center', va='bottom', size = 15)

# x축 라벨 회전
# plt.xticks(rotation=90)
   
# 그래프 제목 및 라벨 설정
plt.title('경기도내 유형별 학교')
plt.xlabel('학교명')
plt.ylabel('학교수')

# 그래프 출력
plt.tight_layout()
# 이미지 저장
plt.savefig('school_type.png', dpi=300, bbox_inches='tight')
plt.show()


# In[183]:


import matplotlib.pyplot as plt

schools = ['평준화 일반고', '비평준화 일반고', '특성화고','자율고', '예고', '마이스터고', '외국어고', '국제고' ]
counts = [209, 188, 103, 3, 5, 3,  8, 3]

line_graph = plt.plot(schools, counts, 'o-', color = 'red')
plt.ylim(0, 240)

# 숫자 넣는 부분, height + 0.5로 숫자 약간 위로 위치하게 조정
for i in range(len(schools)):
    height = counts[i]
    plt.text(schools[i], height + 0.5, '%.1f' %height, ha='center', va='bottom', size = 12)

plt.show()

