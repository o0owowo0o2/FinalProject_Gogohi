#!/usr/bin/env python
# coding: utf-8

# In[1]:


# 먼저, 명령프롬프트를 관리자 권한 실행하고, 아래와 같이 패키지를 설치해 줍니다.
# (base) C:\Windows\system32>cd C:\Python_Study\Lecture03
# (base) C:\Python_Study\Lecture03>pip install JPype1-1.2.0-cp37-cp37m-win_amd64.whl
# (base) C:\Python_Study\Lecture03>pip install konlpy
# (base) C:\Python_Study\Lecture03>pip show konlpy
# 프로젝트에 필요한 파이썬 패키지를 임포트한다.
import json
import re
from konlpy.tag import Okt
from collections import Counter
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import font_manager, rc
from wordcloud import WordCloud


# In[2]:


# json 파일을 읽어서 json.loads() data 객체에 저장한다. 한글이 깨지지 않도록
# utf-8 형식으로 인코딩한다. encoding='utf-8'
# 임포트한 패키지는 다음과 같은 용도로 사용한다.
# json : json 파일을 다루기 위한 모듈
# Okt : 한글 품사 태깅을 위한 모듈
inputFileName = './data/student_counseling_2024-09-10'
data = json.loads(open(inputFileName+'.json', 'r', encoding='utf-8').read())
data # 출력하여 내용 확인


# In[3]:


# Page257 : 2. data에 저장된 json 구조에서 'interest' 키의 내용이 우리가 분석할
# 상담글 본문 데이터다. 'interest'키의 데이터에서 품사가 명사인 단어만 추출한다.
# 'message'키의 값(상담 본문 내용)에서 문자나 숫자가 아닌 것 r'[^\w]'은 공백으로
# 치환하여 re.sub() 제거하면서 연결하여 전체를 하나의 문자열로 구성한다.
message = ''
for item in data:
    if 'interest' in item.keys():
        message = message + re.sub(r'[^\w]', ' ', item['interest']) + ''
message # 출력하여 내용 확인


# In[4]:


# 품사 태깅 패키지인 Okt를 사용하여 명사만 추출해 nlp.nouns() message_N에 저장한다.
# In[*] 표시는 "처리중"이라는 표시인데, 조금만 기다려 주시기 바랍니다.
nlp = Okt()
message_N = nlp.nouns(message)
message_N # 출력하여 내용 확인


# In[5]:


# Page258 : [5] 데이터 탐색 및 분석 모델 구축
# 1. 명사를 추출하여 저장한 message_N에 있는 단어들을 탐색해보자.
# Counter() 함수를 사용하여 단어별 출현 횟수를 계산한다.
count = Counter(message_N)
count # 출력하여 내용 확인


# In[6]:


# 출현 횟수가 많은 상위 80개의 단어 중에서 길이가 1보다 큰 것만 word_count 딕셔너리에
# 저장하면서 출력하여 확인한다.
word_count = dict()
for tag, counts in count.most_common(80):
    if(len(str(tag))>1):
        word_count[tag] = counts
        print("%s : %d" % (tag, counts))


# In[7]:


# 2. 단어 빈도를 시각적으로 탐색하기 위해 히스토그램을 그려보자.
# 히스토그램에 레이블을 한글로 표시하기 위해 한글 폰트인 맑은고딕체 malgun.ttf를
# 설정한다. matplotlib.rc()
# C:/Windows/Fonts 폴더 안에서 한글로 "맑은 고딕" 선택하고, "맑은 고딕 보통" 클릭 선택
# 마우스 우클릭 - 속성에서 malgun.ttf 확인
font_path = "C:/Windows/Fonts/malgun.ttf"
font_name = font_manager.FontProperties(fname = font_path).get_name()
matplotlib.rc('font', family = font_name)


# In[8]:


# 히스토그램을 생성한다.
plt.figure(figsize = (12, 5))
plt.xlabel('키워드')
plt.ylabel('빈도수')
plt.grid(True)
sorted_Keys = sorted(word_count, key = word_count.get, reverse = True)
sorted_Values = sorted(word_count.values(), reverse = True)
plt.bar(range(len(word_count)), sorted_Values, align = 'center')
plt.xticks(range(len(word_count)), list(sorted_Keys), rotation = '75')
plt.show()


# In[9]:


# Page260 : [6] 결과 시각화 : 페이스북 전자신문 페이지의 '4차 산업혁명' 기사에서
# 명사 키워드를 분석하기 위해 단어 구성을 탐색하였다.
# 단어 빈도 분석 결과를 워드클라우드로 시각화해보자.
# 워드클라우드 객체를 생성하고 WordCloud(), word_count에서
# 단어별 빈도수를 계산해서 wc.generate_from_frequencies() cloud 객체에 저장하고,
# 워드클라우드를 생성한다. plt.imshow()
wc = WordCloud(font_path, background_color = 'ivory', width = 800, height = 600)
cloud = wc.generate_from_frequencies(word_count)
plt.figure(figsize = (8, 8))
plt.imshow(cloud)
plt.axis('off')
plt.show()


# In[10]:


# 워드클라우드를 jpg 파일로 저장한다. to_file()
cloud.to_file("./data/twitter_kr_cloud.jpg")


# In[ ]:


# 지금까지, 텍스트에 대한 간단한 단어 분석을 수행해 보았다.


# In[ ]:




