package com.springboot.react.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.springboot.react.entity.Post_SJE;
import com.springboot.react.service.PostService_SJE;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



import java.io.IOException;
import java.util.Optional;

//@RestController 어노테이션은 이 클래스가 RESTful 컨트롤러임을 나타내며,
//스프링 컨테이너에 의해 관리되는 빈으로 등록됩니다.
@RestController
//@RequestMapping 어노테이션은 이 컨트롤러의 모든 메소드에 적용될 기본 URL 경로를 설정합니다.
@RequestMapping("/api/posts_sje")
public class PostController_SJE {
	
	// PostService 타입의 객체를 선언합니다.
    private final PostService_SJE postService;

    // @Autowired 어노테이션은 Spring의 의존성 주입 기능을 이용하여
    // PostService 객체를 자동으로 주입받습니다.
    @Autowired
    public PostController_SJE(PostService_SJE postService) {
        this.postService = postService;
    }

    // PostMapping 어노테이션: HTTP POST 요청을 처리합니다. '/upload' 경로로 요청이 들어오면 해당 메소드가 실행됩니다.
    @PostMapping("/upload")
    public ResponseEntity<?> uploadPost(@RequestParam("post") String postStr) throws IOException {
        // ObjectMapper 인스턴스를 생성하여 JSON 문자열을 자바 객체로 변환합니다.
        ObjectMapper objectMapper = new ObjectMapper();
        Post_SJE post = objectMapper.readValue(postStr, Post_SJE.class); // JSON 문자열을 Post 객체로 변환

        // Post 객체를 데이터베이스에 저장하고, 저장된 객체를 반환받습니다.
        Post_SJE savedPost = postService.savePost(post); // 게시글 저장

        // 응답으로 게시글의 ID와 함께 성공 메시지를 반환합니다.
        return ResponseEntity.ok("게시글이 등록되었습니다. ID: " + savedPost.getBoardNumber());
    }
    
    // @GetMapping 어노테이션은 HTTP GET 요청을 처리합니다.
    // {id}는 경로 변수로, 실제 요청에서는 특정 아이디 값으로 대체됩니다.
    @GetMapping("/{id}")
    public ResponseEntity<Post_SJE> getPostById(@PathVariable Long id) {
        Optional<Post_SJE> post_sje = postService.findById(id);
        // Optional 객체의 값이 존재하면 HTTP 상태 코드 200과 함께 반환,
        // 없으면 404 에러를 반환합니다.
        return post_sje.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 페이징 처리를 추가한 게시글 목록 조회 메서드
    // 기본값으로 page는 0, size는 3으로 설정됩니다.
//    @GetMapping
//    public ResponseEntity<Page<Post_SJE>> getAllPosts(
//            @RequestParam(defaultValue = "0") int page,
//            // 한 페이지에 3개 보임
//            @RequestParam(defaultValue = "3") int size) {
//        Pageable pageable = PageRequest.of(page, size);
//        Page<Post_SJE> posts = postService.findAll(pageable);
//        // 페이징 처리된 게시글 목록을 HTTP 상태 코드 200과 함께 반환합니다.
//        return ResponseEntity.ok(posts);
//    }
    @GetMapping
    public ResponseEntity<Page<Post_SJE>> getAllPosts(
            @RequestParam(defaultValue = "0") int page, // 기본 페이지 번호는 0
            @RequestParam(defaultValue = "3") int size, // 기본 페이지 크기는 3
            @RequestParam(required = false) String search) { // 선택적 검색어 파라미터
        Pageable pageable = PageRequest.of(page, size);
        Page<Post_SJE> posts;
        if (search != null && !search.trim().isEmpty()) {
            // 검색어가 제공된 경우 해당 검색어를 포함하는 게시글 검색
            posts = postService.findAllBySearch(search, pageable);
        } else {
            // 검색어가 없는 경우 모든 게시글 조회
            posts = postService.findAll(pageable);
        }
        return ResponseEntity.ok(posts);
    }
    
    
    // @PutMapping 어노테이션은 HTTP PUT 요청을 처리합니다.
    // 경로 변수 id와 요청 본문에 포함된 Post 객체를 받아 게시글을 업데이트합니다.
    @PutMapping("/{id}")
    public ResponseEntity<Post_SJE> updatePost(@PathVariable Long id, @RequestBody Post_SJE postDetails) {
        Post_SJE updatedPost = postService.updatePost(id, postDetails);
        return ResponseEntity.ok(updatedPost);
    }
    
    // @DeleteMapping 어노테이션은 HTTP DELETE 요청을 처리합니다.
    // 경로 변수 id로 지정된 게시글을 삭제합니다.
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePost(@PathVariable Long id) {
        postService.deletePost(id);
        return ResponseEntity.ok().build();
    }
}
