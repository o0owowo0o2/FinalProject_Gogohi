package com.springboot.react.controller;

import com.springboot.react.model.Address;
import com.springboot.react.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/address")
public class AddressController {

    // AddressService 인스턴스를 자동 주입받아 사용
    @Autowired
    private AddressService addressService;

    @PostMapping("/process")
    public ResponseEntity<?> paymentDone(@RequestBody Address address) {
        try {
            // 주소 정보를 로그에 출력하여 수신 확인
            System.out.println("Received address info: " + address);

            // 주소 정보를 데이터베이스에 저장
            addressService.insertAddressSuccess(address);

            // 주소 정보 처리 성공 메시지를 포함한 ResponseEntity 객체 반환
            return ResponseEntity.ok().body("{\"message\": \"Address processed successfully\"}");
        } catch (Exception e) {
            // 결제 처리 중 발생한 오류를 로그에 출력
            System.err.println("결제 처리 오류: " + e.getMessage());

            // 결제 처리 실패 메시지를 포함한 ResponseEntity 객체 반환
            return ResponseEntity.badRequest().body("{\"message\": \"Failed to process process\"}");
        }
    }
}
