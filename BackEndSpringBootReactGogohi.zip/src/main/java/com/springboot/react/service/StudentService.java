// 패키지 선언
package com.springboot.react.service;

// 필요한 클래스를 임포트합니다.
import com.springboot.react.entity.Student;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

// PostService 인터페이스 정의
public interface StudentService {
    // findById 메서드는 주어진 id를 가진 Post 객체를 찾아 Optional 객체로 반환합니다.
    // Optional을 사용하는 이유는 해당 ID로 Post 객체를 찾을 수 없을 경우를 안전하게 처리하기 위함입니다.
    Optional<Student> findById(Long id);

    // findAll 메서드는 저장된 모든 Post 객체의 리스트를 반환합니다.
    // 이 메서드는 데이터베이스에서 모든 게시글을 조회할 때 사용됩니다.
//    List<Student> findAll();
    
    // 페이징 처리를 위해 수정된 findAll 메서드
    Page<Student> findAll(Pageable pageable);
    
    // updatePost 메서드는 게시글을 수정하는 기능을 선언합니다.
    // 이 메서드는 게시글의 ID와 수정할 게시글 정보(Post 객체)를 매개변수로 받습니다.
    // 매개변수 'id'는 수정하려는 게시글의 식별자입니다.
    // 매개변수 'postDetails'는 수정하려는 게시글의 새로운 정보를 포함한 Post 객체입니다.
    // 반환값은 수정된 Post 객체입니다. 이는 수정이 성공적으로 반영되었음을 나타내며,
    // 일반적으로 수정된 게시글의 최신 상태를 반환합니다.
    Student updateStudent(Long id, Student studentDetails);
    
    // deletePost 메서드는 게시글을 삭제하는 기능을 선언합니다.
    // 이 메서드는 삭제하려는 게시글의 ID를 매개변수로 받습니다.
    // 반환값이 없는 void 타입으로, 성공적으로 게시글을 삭제할 경우 특별한 반환 없이 처리됩니다.
    void deleteStudent(Long id);
    
    // savePost 메서드는 게시글(Post 객체)를 등록(저장)하는 기능을 정의합니다.
    // 메서드의 파라미터로 Post 객체를 받아, 이를 데이터베이스나 다른 저장 매체에 저장합니다.
    // 처리가 완료된 Post 객체를 반환하는 것이 일반적이며, 저장된 객체에는 보통 식별자나
    // 다른 추가 정보(예를 들어, 저장된 시간)가 포함될 수 있습니다.
    Student saveStudent(Student student); // 게시글 등록 메소드
}