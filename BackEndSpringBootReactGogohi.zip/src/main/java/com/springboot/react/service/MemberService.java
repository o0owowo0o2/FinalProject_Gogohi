package com.springboot.react.service;

import com.springboot.react.entity.Member; // Member 엔티티 클래스
import java.util.Optional;

// MemberService 인터페이스 정의
public interface MemberService {
    // saveMember 메소드는 Member 객체를 매개변수로 받아 데이터베이스에 저장합니다.
    // 이 메소드는 Member 엔티티를 저장하거나 업데이트하는 로직을 처리할 수 있습니다.
    // @param member Member 엔티티 인스턴스
    // @return 저장된 Member 엔티티 인스턴스
    Member saveMember(Member member);

    // 특정 memberId를 사용하여 Member를 찾습니다.
    Optional<Member> findByMemberId(String memberId);

    // 특정 memberId를 사용하여 Member 정보를 업데이트합니다.
    // @param memberId 업데이트할 사용자의 ID
    // @param updatedMember 업데이트할 정보가 담긴 Member 객체
    // @return 업데이트된 Member 객체
    Member updateMember(String memberId, Member updatedMember);

    // 특정 memberId를 사용하여 회원 탈퇴(삭제)를 수행합니다.
    // @param memberId 삭제할 사용자의 ID
    void deleteMember(String memberId);
}
