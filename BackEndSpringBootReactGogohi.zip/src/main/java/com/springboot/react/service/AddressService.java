package com.springboot.react.service;

import com.springboot.react.model.Address;

public interface AddressService {
    /**
     * @param address 결제 정보를 담고 있는 Address 객체
     */
    void insertAddressSuccess(Address address);
}
