package com.springboot.react.service;

import com.springboot.react.model.Payment_SJE;

public interface PaymentService_SJE {
	void insertPaymentSuccess(Payment_SJE payment);
}
