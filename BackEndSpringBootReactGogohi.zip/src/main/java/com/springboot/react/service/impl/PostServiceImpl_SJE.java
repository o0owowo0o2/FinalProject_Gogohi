// 필요한 패키지와 라이브러리를 임포트합니다.
package com.springboot.react.service.impl;

import com.springboot.react.entity.Post_SJE;
import com.springboot.react.repository.PostRepository_SJE;
import com.springboot.react.service.PostService_SJE;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

// @Service 어노테이션은 이 클래스가 서비스 계층의 컴포넌트임을 나타내고,
// 스프링의 컨테이너에 의해 빈으로 관리됨을 나타냅니다.
@Service
public class PostServiceImpl_SJE implements PostService_SJE {

    // PostRepository의 인스턴스를 선언합니다.
    private final PostRepository_SJE postRepository_SJE;
    
    // 생성자에 @Autowired를 사용하여 PostRepository의 인스턴스를 자동으로 주입받습니다.
    @Autowired
    public PostServiceImpl_SJE(PostRepository_SJE postRepository) {
        this.postRepository_SJE = postRepository;
    }

    // 조회
    @Override
    public Optional<Post_SJE> findById(Long id) {
        return postRepository_SJE.findById(id);
    }

    // Pageable 객체를 매개변수로 받아 페이징 처리된 Post 목록을 반환합니다.
    @Override
    public Page<Post_SJE> findAll(Pageable pageable) {
        return postRepository_SJE.findAll(pageable);
    }

    // 검색 기능을 추가한 findAllBySearch 메서드입니다.
    @Override
    public Page<Post_SJE> findAllBySearch(String search, Pageable pageable) {
        // 검색어가 제공된 경우 해당 검색어를 포함하는 게시글을 조회합니다.
        if (search != null && !search.trim().isEmpty()) {
            // 제목, 내용, 또는 작성자가 검색어를 포함하는 게시글을 페이지네이션으로 조회합니다.
            return postRepository_SJE.findByBoardTitleContainingOrBoardContentsContainingOrBoardWriterContaining(search, search, search, pageable);
        } else {
            // 검색어가 없는 경우, 모든 게시글을 페이징 처리하여 반환합니다.
            return postRepository_SJE.findAll(pageable);
        }
    }
    
    // id로 특정 Post를 찾고, 제공된 postDetails로 해당 Post를 업데이트하는 메서드입니다.
    @Override
    public Post_SJE updatePost(Long id, Post_SJE postDetails) {
        Post_SJE post = postRepository_SJE.findById(id)
                .orElseThrow(() -> new RuntimeException("Post not found with id " + id));  // Post를 찾지 못하면 예외를 발생시킵니다.

        // 게시글의 제목과 내용을 업데이트합니다. 필요한 경우 다른 필드도 추가할 수 있습니다.
        post.setBoardTitle(postDetails.getBoardTitle());
        post.setBoardContents(postDetails.getBoardContents());

        // 업데이트된 게시글 정보를 저장하고 반환합니다.
        return postRepository_SJE.save(post);
    }
    
    // id를 사용하여 특정 Post를 삭제하는 메서드입니다.
    @Override
    public void deletePost(Long id) {
        Post_SJE post = postRepository_SJE.findById(id)
                .orElseThrow(() -> new RuntimeException("Post not found with id " + id));  // Post를 찾지 못하면 예외를 발생시킵니다.
        postRepository_SJE.delete(post);  // 해당 Post를 삭제합니다.
    }

    // 저장
	@Override
	public Post_SJE savePost(Post_SJE post) {
		return postRepository_SJE.save(post);
	}
}
