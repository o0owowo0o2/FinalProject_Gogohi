package com.springboot.react.service.impl;

import com.springboot.react.entity.Member;
import com.springboot.react.repository.MemberRepository;
import com.springboot.react.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

@Service
public class MemberServiceImpl implements MemberService {

    // 로깅을 위한 Logger 설정
    private static final Logger logger = LoggerFactory.getLogger(MemberServiceImpl.class);
    // 의존성 주입을 통해 MemberRepository와 BCryptPasswordEncoder 사용
    private final MemberRepository memberRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    @Autowired
    public MemberServiceImpl(MemberRepository memberRepository, BCryptPasswordEncoder passwordEncoder) {
        this.memberRepository = memberRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // 회원가입 시 회원 정보를 저장하는 메서드
    @Override
    @Transactional
    public Member saveMember(Member member) {
        // 회원가입 시 비밀번호가 암호화되기 전 로그 출력
        logger.info("회원가입 시 비밀번호 암호화 전: {}", member.getMemberPassword());
        //기존 코드 member.setMemberPassword(passwordEncoder.encode(member.getMemberPassword()));
        // 비밀번호가 이미 BCrypt 해시로 암호화되었는지 확인
        if (!member.getMemberPassword().startsWith("$2a$")) { // BCrypt 해시로 시작하지 않으면 평문 비밀번호로 간주
            // 평문 비밀번호를 BCrypt로 암호화하여 설정
            member.setMemberPassword(passwordEncoder.encode(member.getMemberPassword()));
        }
        
        // 비밀번호가 암호화된 후 로그 출력
        logger.info("회원가입 시 비밀번호 암호화 후: {}", member.getMemberPassword());
        
        // 암호화된 비밀번호를 포함한 회원 정보를 데이터베이스에 저장
        return memberRepository.save(member);
    }

    // 회원 ID로 회원 정보를 조회하는 메서드
    @Override
    public Optional<Member> findByMemberId(String memberId) {
        // 주어진 memberId를 기준으로 회원 정보를 Optional로 반환
        return memberRepository.findByMemberId(memberId);
    }

    // 회원 정보를 업데이트하는 메서드
    @Override
    @Transactional
    public Member updateMember(String memberId, Member updatedMember) {
        // memberId로 회원을 찾고, 없으면 예외 발생
        Member member = memberRepository.findByMemberId(memberId)
            .orElseThrow(() -> new RuntimeException("Member not found with id " + memberId));

        // 회원 정보의 각 필드를 업데이트
        member.setMemberName(updatedMember.getMemberName());
        member.setMemberPhone(updatedMember.getMemberPhone());
        member.setAddress(updatedMember.getAddress());
        member.setAddressDetail(updatedMember.getAddressDetail());
        member.setGender(updatedMember.getGender());
        member.setImagePath(updatedMember.getImagePath());

        // 비밀번호가 null 또는 빈 값이 아닌 경우에만 비밀번호를 업데이트
        if (updatedMember.getMemberPassword() != null && !updatedMember.getMemberPassword().isEmpty()) {
            // 비밀번호가 암호화되기 전 로그 출력
            logger.info("회원정보 수정 시 비밀번호 암호화 전: {}", updatedMember.getMemberPassword());

            // 기존 비밀번호와 다를 때만 비밀번호 암호화 및 업데이트
            if (!passwordEncoder.matches(updatedMember.getMemberPassword(), member.getMemberPassword())) {
                // 새로운 비밀번호를 암호화하여 설정
                member.setMemberPassword(passwordEncoder.encode(updatedMember.getMemberPassword()));
                logger.info("회원정보 수정 시 비밀번호 암호화 후: {}", member.getMemberPassword());
            } else {
                // 비밀번호가 변경되지 않았을 경우 로그 출력
                logger.info("비밀번호가 변경되지 않음. 기존 비밀번호 유지.");
            }
        }

        // 업데이트된 회원 정보를 데이터베이스에 저장
        return memberRepository.save(member);
    }

    // 회원을 삭제하는 메서드
    @Override
    @Transactional
    public void deleteMember(String memberId) {
        // memberId로 회원을 찾고, 없으면 예외 발생
        Member member = memberRepository.findByMemberId(memberId)
                .orElseThrow(() -> new RuntimeException("Member not found with id " + memberId));
        
        // 회원 정보를 데이터베이스에서 삭제
        memberRepository.delete(member);
    }
}
