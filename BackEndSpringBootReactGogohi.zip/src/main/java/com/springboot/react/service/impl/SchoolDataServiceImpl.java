package com.springboot.react.service.impl;

import com.springboot.react.entity.SchoolData;
import com.springboot.react.repository.SchoolDataRepository;
import com.springboot.react.service.SchoolDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SchoolDataServiceImpl implements SchoolDataService {

    private final SchoolDataRepository schoolDataRepository;

    @Autowired
    public SchoolDataServiceImpl(SchoolDataRepository schoolDataRepository) {
        this.schoolDataRepository = schoolDataRepository;
    }

    @Override
    public Page<SchoolData> findAll(Pageable pageable) {
        return schoolDataRepository.findAll(pageable);
    }

    @Override
    public Page<SchoolData> findByOpenApiRank(Integer rank, Pageable pageable) {
        return schoolDataRepository.findByOpenApiRank(rank, pageable);
    }

    @Override
    public Optional<SchoolData> findById(Long id) {
        return schoolDataRepository.findById(id);
    }

    @Override
    public SchoolData saveData(SchoolData data) {
        return schoolDataRepository.save(data);
    }
}
