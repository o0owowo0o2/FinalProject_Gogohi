package com.springboot.react.config;

// 필요한 클래스들을 임포트합니다.
import java.util.Arrays;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;

@Configuration  // 이 클래스를 스프링 구성(설정) 클래스로 선언합니다.
@EnableWebSecurity  // 이 어노테이션을 사용하여 Spring Security 설정을 활성화합니다.
public class SecurityConfig {

    @Bean  // Spring IoC 컨테이너에 의해 관리되는 빈 객체를 생성합니다.
    public BCryptPasswordEncoder passwordEncoder() {
        // 비밀번호를 암호화하는 데 사용되는 BCryptPasswordEncoder의 인스턴스를 생성하고 반환합니다.
        return new BCryptPasswordEncoder();
    }

    // SecurityFilterChain 객체를 생성하는 빈을 정의합니다.
    // 이 빈은 HTTP 보안 구성을 담당합니다.
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .cors()  // CORS (Cross-Origin Resource Sharing) 설정을 활성화합니다.
            .configurationSource(request -> {  // CORS 구성을 정의합니다.
                CorsConfiguration config = new CorsConfiguration();
                config.setAllowedOrigins(Arrays.asList("*","http://localhost:3000", "http://192.168.10.19:3000"));  // 접근을 허용할 출처 목록을 설정합니다.
                config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));  // 허용할 HTTP 메소드를 지정합니다.
                config.setAllowedHeaders(Arrays.asList("*"));  // 허용할 HTTP 헤더를 지정합니다.
                config.setAllowCredentials(false);  // 자격 증명(쿠키 등)을 포함한 요청을 허용할지 여부를 설정합니다.
                return config;  // 구성된 CORS 설정을 반환합니다.
            })
            .and()  // HttpSecurity 객체의 메소드 체인을 계속하기 위해 사용됩니다.
            .csrf().disable();  // CSRF(Cross-Site Request Forgery) 보호 기능을 비활성화합니다.
        
        // 여기에 추가적인 보안 구성을 정의할 수 있습니다.

        return http.build();  // 구성된 HttpSecurity 객체를 반환합니다.
    }
    
}
