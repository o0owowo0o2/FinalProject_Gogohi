package com.springboot.react.repository;

import com.springboot.react.entity.SchoolData;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SchoolDataRepository extends JpaRepository<SchoolData, Long> {
    Page<SchoolData> findAll(Pageable pageable);
    Page<SchoolData> findByOpenApiRank(Integer openApiRank, Pageable pageable);
}
