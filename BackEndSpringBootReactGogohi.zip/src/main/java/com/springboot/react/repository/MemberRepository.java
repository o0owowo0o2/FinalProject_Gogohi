package com.springboot.react.repository;

// 필요한 클래스 임포트
import com.springboot.react.entity.Member; // Member 엔티티 클래스
import org.springframework.data.jpa.repository.JpaRepository; // Spring Data JPA의 JpaRepository
import java.util.Optional;

// MemberRepository 인터페이스는 JpaRepository를 확장합니다.
// JpaRepository에는 엔티티 클래스와 해당 ID 필드의 타입을 제네릭으로 지정합니다.
public interface MemberRepository extends JpaRepository<Member, Long> {
    // 이 인터페이스는 JpaRepository를 상속받아 Member 엔티티에 대한 CRUD 및 페이징 처리를 자동으로 지원받습니다.
    // JpaRepository는 기본적인 CRUD 메서드와 페이징 및 정렬을 위한 메서드를 제공합니다.
    // 여기에는 추가적인 메서드를 정의하지 않아도, Member 엔티티에 대한 기본적인 데이터베이스 작업이 가능합니다.
	Optional<Member> findByMemberId(String memberId);
	
	Optional<Member> findByMemberNumber(Long memberNumber);
}
