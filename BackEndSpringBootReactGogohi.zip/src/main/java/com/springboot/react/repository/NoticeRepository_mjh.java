package com.springboot.react.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.react.entity.Notice_mjh;

public interface NoticeRepository_mjh extends JpaRepository<Notice_mjh, Long> {

	Page<Notice_mjh> findAll(Pageable pageable);
	
	Page<Notice_mjh> findByNoticeTitleContainingOrNoticeContentsContainingOrNoticeWriterContaining(String noticeTitle, String noticeContents, String noticeWriter, Pageable pageable);
	
}
