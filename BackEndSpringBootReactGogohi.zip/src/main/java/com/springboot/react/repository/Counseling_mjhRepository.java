package com.springboot.react.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.react.entity.Counseling_mjh;

public interface Counseling_mjhRepository extends JpaRepository<Counseling_mjh, Long>{

Page<Counseling_mjh> findAll(Pageable pageable);

Page<Counseling_mjh>
findByCounselingTitleContainingOrCounselingContentsContainingOrCounselingWriterContaining(String counselingTitle,
			String counselingContents, String counselingWriter, Pageable pageable);

}
