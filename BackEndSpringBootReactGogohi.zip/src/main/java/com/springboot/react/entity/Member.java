package com.springboot.react.entity;

// JPA 관련 어노테이션을 사용하기 위한 임포트
import javax.persistence.*;
// Lombok 라이브러리의 어노테이션으로 getter, setter, 생성자를 자동으로 생성
import lombok.*;

// 클래스를 데이터베이스의 엔티티로 선언합니다.
@Entity
// 엔티티에 해당하는 데이터베이스 테이블을 지정합니다.
@Table(name = "members")
// Lombok 어노테이션으로 getter 메소드 자동 생성
@Getter
// Lombok 어노테이션으로 setter 메소드 자동 생성
@Setter
// Lombok으로 기본 생성자 자동 생성
@NoArgsConstructor
// Lombok으로 모든 필드를 포함한 생성자 자동 생성
@AllArgsConstructor
public class Member {
    
    // 식별자 필드를 선언하고 자동 생성 전략을 지정합니다. 시퀀스를 사용합니다.
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "member_seq")
    @SequenceGenerator(name = "member_seq", sequenceName = "MEMBER_SEQ", allocationSize = 1)
    private Long memberNumber;
    
    // memberId 필드는 NULL을 허용하지 않습니다.
    @Column(nullable = false)
    private String memberId;

    // memberPassword 필드는 NULL을 허용하지 않습니다.
    @Column(nullable = false)
    private String memberPassword;

    // memberName 필드는 NULL을 허용하지 않습니다.
    @Column(nullable = true)
    private String memberName;
    
    @Column(nullable = true)
    private String memberPhone;
    
    @Column(nullable = true)
    private String address;
    
    @Column(nullable = true)
    private String addressDetail;
    
    @Column(nullable = true)
    private String gender;
    
    // imagePath 필드는 NULL을 허용할 수 있으며, 이미지 파일의 저장 경로를 나타냅니다.
    @Column(nullable = true)
    private String imagePath; // 이미지 파일의 저장 경로
}
