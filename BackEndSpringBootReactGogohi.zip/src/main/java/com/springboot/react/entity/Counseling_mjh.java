package com.springboot.react.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "counselingPosts_mjh")
public class Counseling_mjh {
	// 상담글의 고유 번호 (ID)
    @Id // 이 필드를 테이블의 기본 키로 설정
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "counseling_seq") // ID 값을 자동으로 생성하며, 시퀀스를 사용
    @SequenceGenerator(name = "counseling_seq", sequenceName = "COUNSELING_SEQ", allocationSize = 1) // 시퀀스 생성기 정의
    private Long counselingNumber; // 상담글 번호
    
    // 상담글 제목
    @Column(nullable = false) // 이 필드는 데이터베이스에 null을 허용하지 않음
    private String counselingTitle; // 상담글 제목

    // 상담글 내용
    @Column(nullable = false, length = 1000) // 이 필드는 데이터베이스에 null을 허용하지 않음
    private String counselingContents; // 상담글 내용

    // 상담글 작성자
    @Column(nullable = false) // 이 필드는 데이터베이스에 null을 허용하지 않음
    private String counselingWriter; // 상담글 작성자 이름
    
    @Column(nullable = true)
    private String counselingEmail;
    
    @Column(nullable = false)
    private LocalDate counselingDate;
    
    @Column(nullable = false)
    private String avgRank;
   
}
